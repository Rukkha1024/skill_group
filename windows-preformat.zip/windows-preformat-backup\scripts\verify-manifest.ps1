# Portable checksum verification. No applications, WSL or writers are invoked.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Root,[string]$Manifest='SHA256SUMS.csv')
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
$rootFull=[IO.Path]::GetFullPath($Root)
if ($rootFull -ne [IO.Path]::GetPathRoot($rootFull)) { $rootFull=$rootFull.TrimEnd('\','/') }
$rootPrefix=$rootFull.TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
if (-not (Test-Path -LiteralPath $rootFull -PathType Container)) { throw 'Verification root does not exist' }
$rootAncestor=$rootFull
while ($rootAncestor) {
    if ((Get-Item -LiteralPath $rootAncestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in root ancestry; pass a resolved physical directory' }
    $parent=[IO.Directory]::GetParent($rootAncestor)
    if ($null -eq $parent) { break }
    $rootAncestor=$parent.FullName
}
if ([IO.Path]::IsPathRooted($Manifest)) { $manifestFull=[IO.Path]::GetFullPath($Manifest) }
else { $manifestFull=[IO.Path]::GetFullPath((Join-Path $rootFull $Manifest)) }
$entries=@(Import-Csv -LiteralPath $manifestFull -Encoding UTF8)
if (-not $entries.Count) { throw 'Checksum manifest is empty' }
$errors=[Collections.Generic.List[string]]::new()
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in $entries) {
    if (-not $entry.RelativePath -or [IO.Path]::IsPathRooted($entry.RelativePath)) { throw 'Invalid relative checksum path' }
    $path=[IO.Path]::GetFullPath((Join-Path $rootFull $entry.RelativePath))
    if (-not $path.StartsWith($rootPrefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Checksum path escapes the supplied root' }
    if (-not $seen.Add($path)) { throw 'Duplicate checksum path' }
    # Do not follow a file link or parent junction outside the declared scope.
    $ancestor=$path
    while ($ancestor -and -not $ancestor.Equals($rootFull,[StringComparison]::OrdinalIgnoreCase)) {
        if (Test-Path -LiteralPath $ancestor) {
            $node=Get-Item -LiteralPath $ancestor -Force
            if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in checksum path; resolve its scope explicitly' }
        }
        $ancestor=[IO.Directory]::GetParent($ancestor).FullName
    }
    if ((Get-Item -LiteralPath $rootFull -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Verification root is a reparse point; pass its actual directory' }
    $size=0L
    if (-not [long]::TryParse($entry.Bytes,[ref]$size) -or $size -lt 0 -or $entry.SHA256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid size or SHA256 in checksum manifest' }
    try {
        $file=Get-Item -LiteralPath $path -ErrorAction Stop
        if ($file.PSIsContainer) { throw 'Expected a file, not a directory' }
        if ($file.Length -ne $size) { $errors.Add('Size mismatch: '+$entry.RelativePath); continue }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256 -ErrorAction Stop).Hash -ne $entry.SHA256) { $errors.Add('Hash mismatch: '+$entry.RelativePath) }
    } catch { $errors.Add('Unreadable or missing: '+$entry.RelativePath+' ('+$_.Exception.GetType().Name+')') }
}
if ($errors.Count) { throw ($errors -join "`n") }
[pscustomobject]@{Root=$rootFull;Manifest=$manifestFull;FilesVerified=$entries.Count;Valid=$true;ReadOnly=$true}
