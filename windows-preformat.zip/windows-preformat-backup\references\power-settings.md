# Power options: this user's restore target

The default is **최고의 성능 (Ultimate Performance)** plus **디스플레이 끄기: 없음 (Never)** for both AC and DC. This means the actual Ultimate Performance power plan, not merely a similarly named plan or the Windows Settings Best performance overlay. Later explicit user instructions override this preference.

## Prepare and review

Read current state without changing it. Capture output, exit status and observation time for:

~~~powershell
powercfg /list
powercfg /getactivescheme
powercfg /query SCHEME_CURRENT SUB_VIDEO VIDEOIDLE
~~~

Save these observations under the new snapshot's inventory/power-settings area and include them in its manifest. Preserve the original active plan GUID and the AC/DC display timeout values separately from the desired target. A timeout of 0 means Never; a nonzero value is seconds. Do not copy an old timeout into the desired target. The original observations are rollback evidence, not instructions to restore a power-saving plan.

Include a desktop-power target and the Korean guide/paste prompt instruction: “전원 구성표를 최고의 성능(Ultimate Performance)으로 활성화하고, 전원 연결 및 배터리 사용 모두 디스플레이 끄기를 없음으로 설정한 뒤 현재 값을 검증해줘.” Power settings are configured independently of the desktop-settings payload; desktop-settings.ps1 does not collect/apply/verify this category.

## Restore

1. Inspect available plans first. Reuse the built-in Ultimate Performance plan or a previously created and verified duplicate of that template; do not repeatedly create plans on continuation. The Windows Ultimate Performance template GUID is e9a42b02-d5df-448d-aa00-03f14749eb61. Do not trust a custom plan's display name alone.
2. If no verified Ultimate Performance plan exists, run powercfg /duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 once. Check exit status and use the new GUID returned by that command, not an assumed template GUID. Record its provenance in continuation evidence. If unsupported or denied, report the actual failure; a Balanced/High performance plan is not successful fulfillment of this target. Continue independent restore items.
3. Activate the resolved plan and set both display timeouts to Never. Use an elevated context when Windows requires it. Substitute the actual GUID below; check every native command's exit status before proceeding.

~~~powershell
# Set this to the GUID resolved from the existing plan or duplicatescheme output.
$ultimatePlanGuid = '<resolved-Ultimate-Performance-GUID>'
powercfg /setactive $ultimatePlanGuid
if ($LASTEXITCODE -ne 0) { throw 'Cannot activate Ultimate Performance' }
powercfg /setacvalueindex $ultimatePlanGuid SUB_VIDEO VIDEOIDLE 0
if ($LASTEXITCODE -ne 0) { throw 'Cannot set AC display timeout' }
powercfg /setdcvalueindex $ultimatePlanGuid SUB_VIDEO VIDEOIDLE 0
if ($LASTEXITCODE -ne 0) { throw 'Cannot set DC display timeout' }
powercfg /setactive $ultimatePlanGuid
if ($LASTEXITCODE -ne 0) { throw 'Cannot apply power settings' }
~~~

Do not infer permission to change sleep, hibernation, lid/power-button behavior, CPU tuning, or other power settings beyond activating the requested plan and setting display timeouts.

## Acceptance

Read powercfg /getactivescheme and powercfg /query SCHEME_CURRENT SUB_VIDEO VIDEOIDLE again, checking query exit status. The active GUID must be the verified Ultimate Performance plan, and both AC/DC setting indices must be 0x00000000. Save fresh command output and timestamps in the restore results; populate desktop-power.Settings with Verified only when all three conditions hold. Otherwise use Partial/Failed with the actual evidence. Do not merge historical collection output into current success evidence.

Recheck after a reboot or any later plan change before handoff. If an OEM tool or policy resets it, report the current mismatch instead of declaring completion from an earlier successful command.

Command reference: [Microsoft powercfg documentation](https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options).
