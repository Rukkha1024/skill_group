# Deletes only journaled, unchanged, session-owned artifacts. Preview is read-only.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Journal,[switch]$Apply,[string]$ResultPath,[string[]]$ProtectedRoots=@())
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
function Full([string]$Path){[IO.Path]::GetFullPath($Path).TrimEnd('\','/')}
function Within([string]$Path,[string]$Root){$Path.Equals($Root,[StringComparison]::OrdinalIgnoreCase) -or $Path.StartsWith($Root+'\',[StringComparison]::OrdinalIgnoreCase)}
function NoLinks([string]$Path){
 $node=$Path
 while($node){
  if(Test-Path -LiteralPath $node){if((Get-Item -LiteralPath $node -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse point in cleanup ancestry'}}
  $parent=[IO.Directory]::GetParent($node);if($null -eq $parent){break};$node=$parent.FullName
 }
}
function HashMatch([string]$Path,[string]$Hash){
 if($Hash -notmatch '^[0-9a-fA-F]{64}$' -or -not(Test-Path -LiteralPath $Path -PathType Leaf)){throw 'Missing file/hash in cleanup contract'}
 if((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $Hash){throw 'Cleanup/retained file hash changed'}
}
$j=Get-Content -LiteralPath $Journal -Raw -Encoding UTF8|ConvertFrom-Json
if($j.SchemaVersion -ne 2 -or -not $j.SessionId -or -not $j.WorkRoot){throw 'Session-owned v2 work journal required'}
$root=Full $j.WorkRoot;NoLinks $root
if($root -eq (Full ([IO.Path]::GetPathRoot($root))) -or $root -eq (Full $env:USERPROFILE) -or $root -eq (Full $env:TEMP)){throw 'Cleanup root is too broad'}
$protect=@($j.ProtectedRoots)+@($ProtectedRoots)+@($env:SystemRoot,$env:ProgramFiles,${env:ProgramFiles(x86)},(Join-Path $env:USERPROFILE '.ssh'),(Join-Path $env:USERPROFILE '.codex'),(Join-Path $env:USERPROFILE '.claude'),(Join-Path $env:USERPROFILE '.local\share'))
foreach($special in @('Desktop','MyDocuments')){$p=[Environment]::GetFolderPath($special);if($p){$protect+= $p}}
$protect+=Join-Path $env:USERPROFILE 'Downloads'
$wsl=@(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss\*' -ErrorAction SilentlyContinue)
foreach($distribution in $wsl){if($distribution.BasePath){$protect+=$distribution.BasePath}}
$protect=@($protect|Where-Object {$_}|ForEach-Object {Full $_})
$candidates=[Collections.Generic.List[object]]::new();$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($a in @($j.Artifacts)){
 if($a.Owned -ne $true -or $a.Disposable -ne $true){throw 'Artifact ownership/disposability missing'}
 if(-not [IO.Path]::IsPathRooted($a.Path)){throw 'Artifact path must be absolute'}
 $path=Full $a.Path;NoLinks $path
 if(-not(Within $path $root) -or -not $seen.Add($path)){throw 'Outside work root or duplicate artifact'}
 foreach($p in $protect){if((Within $path $p) -or (Within $p $path)){throw 'Protected backup/live data overlaps disposable artifact'}}
 if(-not(Test-Path -LiteralPath $path)){continue}
 $item=Get-Item -LiteralPath $path -Force;$count=1;$bytes=0L
 if($item.PSIsContainer){
  $all=@(Get-ChildItem -LiteralPath $path -Recurse -Force)
  if(@($all|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw 'Linked entry inside disposable directory'}
  $actual=@($all|Where-Object {-not $_.PSIsContainer});$declared=@($a.Files)
  if($actual.Count -ne $declared.Count){throw 'Unregistered/new file in disposable directory'}
  $known=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  foreach($f in $declared){
   if(-not [IO.Path]::IsPathRooted($f.Path)){throw 'Directory member path must be absolute'}
   $member=Full $f.Path;NoLinks $member
   if(-not(Within $member $path) -or $member -eq $path -or -not $known.Add($member)){throw 'Invalid/duplicate directory file entry'}
   HashMatch $member $f.SHA256
  }
  $count=$actual.Count;$bytes=[long](($actual|Measure-Object Length -Sum).Sum)
 }else{HashMatch $path $a.SHA256;$bytes=$item.Length}
 $candidates.Add([pscustomobject]@{Path=$path;Files=$count;Bytes=$bytes})
}
# Overlapping artifacts would double-count and can hide later validation errors.
for($i=0;$i -lt $candidates.Count;$i++){for($k=$i+1;$k -lt $candidates.Count;$k++){if((Within $candidates[$i].Path $candidates[$k].Path) -or (Within $candidates[$k].Path $candidates[$i].Path)){throw 'Overlapping artifact registrations'}}}
foreach($retained in @($j.RetainedFiles)){
 $p=Full $retained.Path;NoLinks $p;HashMatch $p $retained.SHA256
 foreach($a in $candidates){if(Within $p $a.Path){throw 'Retained evidence would be deleted'}}
}
foreach($launcher in @($j.RetainedLaunchers)){
 foreach($p in @($launcher.Path)+@($launcher.Paths)){
  $p=Full $p;NoLinks $p
  if(-not(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Retained launcher dependency missing'}
  foreach($a in $candidates){if(Within $p $a.Path){throw 'Retained launcher depends on disposable artifact'}}
 }
}
if($Apply -and -not $ResultPath){throw 'Apply requires a result path outside disposable artifacts'}
if($ResultPath){$resultFull=Full $ResultPath;NoLinks $resultFull;foreach($a in $candidates){if(Within $resultFull $a.Path){throw 'Result would be deleted'}};if($resultFull -eq (Full $Journal)){throw 'Original journal is immutable'}}
if($candidates.Count){
 if($PSVersionTable.PSEdition -eq 'Core'){Import-Module Appx -UseWindowsPowerShell -ErrorAction Stop}
 $processes=@(Get-CimInstance Win32_Process);$services=@(Get-CimInstance Win32_Service);$packages=@(Get-AppxPackage)
 $tasks=@(Get-ScheduledTask)
 foreach($a in $candidates){
  foreach($process in $processes){
   if($process.ExecutablePath -and (Within (Full $process.ExecutablePath) $a.Path)){throw 'Running executable uses disposable artifact'}
   if($process.ProcessId -ne $PID -and $process.CommandLine -and $process.CommandLine.Contains($a.Path)){throw 'Running command references disposable artifact'}
  }
  foreach($service in $services){if($service.PathName -and $service.PathName.Contains($a.Path)){throw 'Service depends on disposable artifact'}}
  foreach($package in $packages){if($package.InstallLocation -and (Within (Full $package.InstallLocation) $a.Path)){throw 'Installed Appx depends on disposable artifact'}}
  foreach($task in $tasks){foreach($action in $task.Actions){if(($action.Execute -and $action.Execute.Contains($a.Path)) -or ($action.Arguments -and $action.Arguments.Contains($a.Path))){throw 'Scheduled task references disposable artifact'}}}
 }
 foreach($name in @($j.SessionTaskNames)){if($tasks|Where-Object {$_.TaskName -eq $name}){throw 'Session continuation task not removed'}}
}
if($Apply){
 foreach($a in $candidates){
  # Recheck immediately before same-shell LiteralPath deletion.
  NoLinks $a.Path
  $artifact=@($j.Artifacts|Where-Object {(Full $_.Path) -eq $a.Path})[0]
  if((Get-Item -LiteralPath $a.Path -Force).PSIsContainer){
   $entries=@(Get-ChildItem -LiteralPath $a.Path -Recurse -Force)
   if(@($entries|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count -or @($entries|Where-Object {-not $_.PSIsContainer}).Count -ne @($artifact.Files).Count){throw 'Disposable tree changed after preview'}
   foreach($f in $artifact.Files){HashMatch (Full $f.Path) $f.SHA256}
  }else{HashMatch $a.Path $artifact.SHA256}
  Remove-Item -LiteralPath $a.Path -Recurse -Force -ErrorAction Stop
  if(Test-Path -LiteralPath $a.Path){throw 'Artifact removal incomplete'}
 }
}
$result=[pscustomobject]@{SchemaVersion=2;SessionId=$j.SessionId;Applied=[bool]$Apply;Status=if($Apply){'Verified'}else{'Preview'};RemovedFiles=if($Apply){($candidates|Measure-Object Files -Sum).Sum}else{0};CandidateBytes=($candidates|Measure-Object Bytes -Sum).Sum;Artifacts=$candidates.ToArray();ProtectedRoots=$protect;CheckedAt=(Get-Date).ToUniversalTime().ToString('o')}
if($Apply){$result|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $ResultPath -Encoding UTF8}
$result|ConvertTo-Json -Depth 8
