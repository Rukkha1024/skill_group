#!/usr/bin/env bash
# Baseline and static package metadata; no shell startup or agent execution.
set -euo pipefail
out=${1:?new output directory required}
user_home=${2:-$HOME}
if [ -e "$out" ]; then printf 'Use a new snapshot output directory.\n' >&2; exit 2; fi
umask 077
mkdir -p "$out"
redact() {
  sed -E 's#(https?://)[^/@"\\[:space:]]+:[^/@"\\[:space:]]+@#\1[REDACTED]@#g; s#(/t/)[^/"\\[:space:]]+#\1[REDACTED]#g; s#([?&](token|key|password|secret|auth)=)[^&"\\[:space:]]+#\1[REDACTED]#Ig; s#((password|passwd|token|secret|api_key|apikey)[[:space:]]*=[[:space:]]*)[^,"\\[:space:]]+#\1[REDACTED]#Ig'
}
capture() {
  local name=$1
  shift
  local err_fd err_pid err_code=0
  local -a codes
  exec {err_fd}> >(redact > "$out/$name.stderr.txt")
  err_pid=$!
  if "$@" 2>&"$err_fd" | redact > "$out/$name"; then
    codes=("${PIPESTATUS[@]}")
  else
    codes=("${PIPESTATUS[@]}")
  fi
  exec {err_fd}>&-
  if wait "$err_pid"; then err_code=0; else err_code=$?; fi
  printf '%s\t%s\t%s\t%s\n' "$name" "${codes[0]}" "${codes[1]}" "$err_code" >> "$out/command-status.tsv"
}
capture os-release.txt cat /etc/os-release
capture identity.txt id
capture kernel.txt uname -a
capture disk.txt df -h /
if command -v dpkg-query >/dev/null 2>&1; then capture dpkg-installed.tsv dpkg-query -W '-f=${binary:Package}\t${Version}\t${Architecture}\t${db:Status-Status}\n'; fi
if command -v apt-mark >/dev/null 2>&1; then
  capture apt-manual.txt apt-mark showmanual
  capture apt-auto.txt apt-mark showauto
  capture apt-hold.txt apt-mark showhold
fi
if [ -f /etc/wsl.conf ]; then capture wsl.conf.txt cat /etc/wsl.conf; fi
if [ -f /etc/fstab ]; then capture fstab.txt cat /etc/fstab; fi
capture tool-locations.txt bash --noprofile --norc -c 'for item in node npm python3 pip3 conda cargo rustup git ssh codex claude gemini qwen droid cursor-agent; do command -v "$item" || true; done'
# Only names/sizes/existence; configuration contents and credentials stay private.
capture agent-settings-discovery.txt bash --noprofile --norc -c 'codex_home=${CODEX_HOME:-$1/.codex}; for file in "$codex_home/config.toml" "$codex_home/hooks.json" "$codex_home/AGENTS.md" "$1/.claude/settings.json" "$1/.claude/settings.local.json" "$1/.claude/CLAUDE.md" "$1/.claude.json"; do if [ -f "$file" ]; then stat -c "%n\t%s\tMetadataOnly" "$file"; else printf "%s\tMissing\tMetadataOnly\n" "$file"; fi; done' _ "$user_home"
capture user-install-directories.txt ls -ld "$user_home"/miniconda "$user_home"/miniconda3 "$user_home"/anaconda3 "$user_home"/.nvm "$user_home"/.cargo "$user_home"/.rustup "$user_home"/.local/bin
if [ -d "$user_home/.ssh" ] || [ -L "$user_home/.ssh" ]; then
  capture ssh-directory.txt ls -ld "$user_home/.ssh"
  capture ssh-resolved-path.txt readlink -f "$user_home/.ssh"
  capture ssh-file-metadata.txt find "$user_home/.ssh" -maxdepth 2 -type f -printf '%P\t%s\n'
fi
if [ -d "$user_home/.local/bin" ]; then capture local-bin.txt ls -la "$user_home/.local/bin"; fi
if [ -d "$user_home/.nvm/versions/node" ]; then
  capture nvm-installations.txt ls -1 "$user_home/.nvm/versions/node"
  for node_dir in "$user_home"/.nvm/versions/node/*; do
    [ -d "$node_dir/lib/node_modules" ] || continue
    # Read only package headers; do not copy possible URL-bearing full manifests.
    python_reader=/usr/bin/python3
    if [ -x "$python_reader" ]; then
      capture "npm-global-$(basename "$node_dir").json" "$python_reader" -c 'import glob,json,os,sys; root=sys.argv[1]; result=[]; paths=glob.glob(root+"/*/package.json")+glob.glob(root+"/@*/*/package.json");
for path in sorted(paths):
 try:
  with open(path,encoding="utf-8") as f: data=json.load(f)
  result.append({"name":data.get("name"),"version":data.get("version"),"path":os.path.dirname(path)})
 except Exception as e: result.append({"path":path,"error":type(e).__name__})
print(json.dumps(result,ensure_ascii=False,indent=2))' "$node_dir/lib/node_modules"
    else
      printf '%s\t127\t0\t0\n' "npm-global-$(basename "$node_dir").json" >> "$out/command-status.tsv"
    fi
  done
fi
if [ -f "$user_home/.conda/environments.txt" ]; then capture conda-environment-paths.txt cat "$user_home/.conda/environments.txt"; fi
if [ -f "$user_home/.nvm/alias/default" ]; then capture nvm-default-alias.txt cat "$user_home/.nvm/alias/default"; fi
if command -v systemctl >/dev/null 2>&1; then capture enabled-services.txt systemctl list-unit-files --state=enabled --no-pager; fi
printf '%s\n' \
 'This is baseline/static inventory, not a full filesystem or SSH-key backup.' \
 'Non-login PATH may omit user managers; inspect the recorded user installation directories.' \
 'Capture per-environment Python/Conda/Rust/other manager inventories where present and in scope.' \
 'Status columns: file, producer exit, stdout-redactor exit, stderr-redactor exit; outputs are waited/flushed.' \
 'Missing directories can be expected; inspect stderr. Missing Python means static npm scan needs supplementation.' \
 'Do not execute AI agents merely to read their version; some self-update.' \
 'Keep original inventory separate from the latest desired restore target.' > "$out/supplementation.txt"
printf '%s\n' 'Agent settings discovery is metadata only. Collect the selected private settings and referenced dependencies separately; WSL exports exclude mounted Windows files.' >> "$out/supplementation.txt"
printf 'WSL baseline inventory saved: %s\n' "$out"
