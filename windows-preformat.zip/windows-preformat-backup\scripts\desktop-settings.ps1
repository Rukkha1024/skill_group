# Start menu, taskbar, Office template, File Explorer Quick Access, Notepad++, app settings folders, desktop icon layout and font backup/restore/verify.
# Collect writes only to a new output directory. Restore previews unless -Apply. Verify is read-only.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Collect','Restore','Verify')][string]$Mode,
    [string]$OutputDirectory,
    [string]$Source,
    [ValidateSet('StartMenu','Taskbar','OfficeTemplates','QuickAccess','NotepadPlusPlus','AppFolders','DesktopIcons','Fonts')][string[]]$Category=@('StartMenu','Taskbar','OfficeTemplates','QuickAccess','NotepadPlusPlus','AppFolders','DesktopIcons','Fonts'),
    # Extra app folders for AppFolders, as 'Name|Folder|ProcessName'.
    [string[]]$ExtraAppFolder=@(),
    [switch]$NoScreenshot,
    # Font pack folders (zips allowed) to back up with Fonts and install on restore.
    [string[]]$FontSource=@(),
    [hashtable]$PathMap=@{},
    [string]$RollbackDirectory,
    [string]$ResultPath,
    [switch]$ExactQuickAccess,
    [switch]$Apply
)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
$utf8=[Text.UTF8Encoding]::new($false)
$now=(Get-Date).ToUniversalTime().ToString('o')
$documents=[Environment]::GetFolderPath('MyDocuments')
$startState=Join-Path $env:LOCALAPPDATA 'Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState'
$taskbarPins=Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
$quickAccessFile=Join-Path $env:APPDATA 'Microsoft\Windows\Recent\AutomaticDestinations\f01b4d95cf55d32a.automaticDestinations-ms'
$quickAccessNamespace='shell:::{679f85cb-0220-4080-b29b-5540cc05aab6}'
$advanced='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
# Allowlisted per-user values; unknown or absent names are skipped, never invented.
$registrySpecs=@{
    StartMenu=@(
        @{Path=$advanced;Names=@('Start_Layout','Start_TrackDocs','Start_TrackProgs','Start_IrisRecommendations','Start_AccountNotifications','Start_RecoPersonalizedSites','Start_ShowClassicMode')},
        @{Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Start';Names=@('ShowRecentList','ShowFrequentList','ShowAllPinsList','AllAppsViewMode','VisiblePlaces','RightCompanionToggledOpen')})
    Taskbar=@(
        @{Path=$advanced;Names=@('TaskbarAl','TaskbarDa','TaskbarMn','TaskbarSi','TaskbarSmallIcons','ShowTaskViewButton','ShowCopilotButton','TaskbarGlomLevel','MMTaskbarEnabled','MMTaskbarMode','MMTaskbarGlomLevel','TaskbarSd','TaskbarBadges','TaskbarFlashing','TaskbarAutoHideInTabletMode')},
        @{Path="$advanced\TaskbarDeveloperSettings";Names=@('TaskbarEndTask')},
        @{Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Search';Names=@('SearchboxTaskbarMode')})
}
# Binary pin-order blobs are restored with the pins but are not compared during verification.
$taskbandPath='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband'
$taskbandNames=@('Favorites','FavoritesResolve','FavoritesVersion','FavoritesChanges')
$stuckRects='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3'
$officeProcesses=@('WINWORD','POWERPNT','EXCEL','OUTLOOK')

function Save-Json([string]$Path,$Value){[IO.File]::WriteAllText($Path,(ConvertTo-Json -InputObject $Value -Depth 12),$utf8)}
function Read-Json([string]$Path){$data=Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json;foreach($item in @($data)){if($null -ne $item){$item}}}
# A file locked by a running app hashes as $null and therefore never matches.
function Hash([string]$Path){try{(Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash}catch{$null}}
function Get-OfficeVersions{@(Get-ChildItem 'HKCU:\Software\Microsoft\Office' -ErrorAction SilentlyContinue|Where-Object {$_.PSChildName -match '^\d+\.\d+$'}|ForEach-Object PSChildName)}
function Office-Specs([string[]]$Versions){
    foreach($v in $Versions){
        @{Path="HKCU:\Software\Microsoft\Office\$v\Word\Options";Names=@('PersonalTemplates','STARTUP-PATH')}
        @{Path="HKCU:\Software\Microsoft\Office\$v\PowerPoint\Options";Names=@('PersonalTemplates')}
        @{Path="HKCU:\Software\Microsoft\Office\$v\Excel\Options";Names=@('PersonalTemplates','AltStartup')}
        @{Path="HKCU:\Software\Microsoft\Office\$v\Common\General";Names=@('UserTemplates','SharedTemplates')}
    }
}
function Read-Values($Specs){
    foreach($spec in $Specs){
        $key=Get-Item -LiteralPath $spec.Path -ErrorAction SilentlyContinue
        if(-not $key){continue}
        foreach($name in $spec.Names){
            if($key.GetValueNames() -notcontains $name){continue}
            $kind=$key.GetValueKind($name).ToString();$value=$key.GetValue($name,$null,'DoNotExpandEnvironmentNames')
            if($kind -eq 'Binary'){$value=B64 $value}
            [pscustomobject]@{Path=$spec.Path;Name=$name;Kind=$kind;Value=$value}
        }
    }
}
# Empty binary values arrive as $null once PowerShell unrolls them.
function B64($Value){if($null -eq $Value){return ''};return [Convert]::ToBase64String([byte[]]$Value)}
function Plain($Value){if($Value -is [Array]){return ($Value -join "`n")};return [string]$Value}

# Old profile/known-folder prefixes map to the current ones; explicit -PathMap entries win.
function New-PathMap($Snapshot){
    $map=[ordered]@{}
    foreach($k in $PathMap.Keys){$map[[string]$k]=[string]$PathMap[$k]}
    foreach($pair in @(@($Snapshot.Documents,$documents),@($Snapshot.AppData,$env:APPDATA),@($Snapshot.LocalAppData,$env:LOCALAPPDATA),@($Snapshot.Profile,$env:USERPROFILE))){
        if($pair[0] -and -not $map.Contains($pair[0])){$map[$pair[0]]=$pair[1]}
    }
    return $map
}
function Map-Path([string]$Value,$Map){
    if(-not $Value){return $Value}
    foreach($old in @($Map.Keys|Sort-Object Length -Descending)){
        if($Value.StartsWith($old,[StringComparison]::OrdinalIgnoreCase)){return $Map[$old]+$Value.Substring($old.Length)}
    }
    return $Value
}
function Map-Value($Entry,$Map){
    if($Entry.Kind -in @('String','ExpandString')){return Map-Path ([string]$Entry.Value) $Map}
    if($Entry.Kind -eq 'MultiString'){return @(@($Entry.Value)|ForEach-Object {Map-Path ([string]$_) $Map})}
    return $Entry.Value
}
function Convert-RegistryValue($Entry,$Value){
    switch($Entry.Kind){
        'Binary'{return ,([Convert]::FromBase64String([string]$Value))}
        'DWord'{return [int]$Value}
        'QWord'{return [long]$Value}
        'MultiString'{return [string[]]@($Value)}
        default{return [string]$Value}
    }
}
function Get-QuickAccess{
    $shell=New-Object -ComObject Shell.Application
    $folder=$shell.Namespace($quickAccessNamespace)
    if(-not $folder){return @()}
    @(foreach($item in @($folder.Items())){
        [pscustomobject]@{Name=$item.Name;Path=$item.Path;IsFolder=[bool]$item.IsFolder;Pinned=[bool]$item.ExtendedProperty('System.Home.IsPinned')}
    })
}
function Get-TaskbarPins{
    if(-not (Test-Path -LiteralPath $taskbarPins)){return @()}
    $wsh=New-Object -ComObject WScript.Shell
    @(foreach($file in @(Get-ChildItem -LiteralPath $taskbarPins -Filter '*.lnk' -File -Force)){
        $link=$wsh.CreateShortcut($file.FullName)
        [pscustomobject]@{File=$file.Name;TargetPath=$link.TargetPath;Arguments=$link.Arguments;WorkingDirectory=$link.WorkingDirectory}
    })
}
function Get-TrayIcons{
    @(Get-ChildItem 'HKCU:\Control Panel\NotifyIconSettings' -ErrorAction SilentlyContinue|ForEach-Object {
        $p=Get-ItemProperty -LiteralPath $_.PSPath
        if($p.ExecutablePath){[pscustomobject]@{Key=$_.PSChildName;ExecutablePath=$p.ExecutablePath;IsPromoted=if($null -ne $p.IsPromoted){[int]$p.IsPromoted}else{$null}}}
    })
}
function Get-StartPins([string]$Path){
    try{Export-StartLayout -Path $Path;$json=Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json;return @($json.pinnedList|ForEach-Object {if($_.desktopAppLink){$_.desktopAppLink}elseif($_.packagedAppId){$_.packagedAppId}elseif($_.desktopAppId){$_.desktopAppId}})}
    catch{return $null}
}
function Get-AutoHide{$s=(Get-ItemProperty -LiteralPath $stuckRects -ErrorAction SilentlyContinue).Settings;if($s -and $s.Length -gt 8){return [bool]($s[8] -band 1)};return $null}
# Office template roots: user templates, custom/personal template folders, add-in startup folders, ribbon/QAT files.
function Get-OfficeRoots($Values){
    $roots=[ordered]@{
        Templates=@{Path=(Join-Path $env:APPDATA 'Microsoft\Templates');Policy='Replace'}
        CustomOfficeTemplates=@{Path=(Join-Path $documents 'Custom Office Templates');Policy='Replace'}
        WordStartup=@{Path=(Join-Path $env:APPDATA 'Microsoft\Word\STARTUP');Policy='KeepExisting'}
        ExcelXLSTART=@{Path=(Join-Path $env:APPDATA 'Microsoft\Excel\XLSTART');Policy='KeepExisting'}
        RibbonQat=@{Path=(Join-Path $env:LOCALAPPDATA 'Microsoft\Office');Policy='Replace';Filter='*.officeUI';NoRecurse=$true}
    }
    $index=0
    foreach($entry in @($Values|Where-Object {$_.Name -in @('PersonalTemplates','UserTemplates','STARTUP-PATH','AltStartup')})){
        $path=[Environment]::ExpandEnvironmentVariables([string]$entry.Value)
        if($path -and -not $path.StartsWith('\\') -and -not (@($roots.Values|ForEach-Object {$_.Path}) -contains $path)){
            $roots["Configured$index"]=@{Path=$path;Policy=if($entry.Name -in @('STARTUP-PATH','AltStartup')){'KeepExisting'}else{'Replace'};ConfiguredBy="$($entry.Path)\$($entry.Name)"};$index++
        }
    }
    return $roots
}
function Office-Files([string]$Root,$Spec){
    if(-not (Test-Path -LiteralPath $Root -PathType Container)){return @()}
    $filter=if($Spec.Filter){$Spec.Filter}else{'*'}
    $items=if($Spec.NoRecurse){Get-ChildItem -LiteralPath $Root -Filter $filter -File -Force}else{Get-ChildItem -LiteralPath $Root -Filter $filter -File -Force -Recurse}
    # Office lock files and Microsoft-managed downloaded LiveContent are regenerated, not user templates.
    @($items|Where-Object {$_.Name -notlike '~$*' -and $_.FullName.Substring($Root.Length) -notmatch '^\\LiveContent\\'})
}

# Notepad++: portable installs (doLocalConf.xml) keep settings beside the exe; otherwise %APPDATA%\Notepad++.
# Cloud settings move config files but session.xml and backup\ stay in the base folder. -settingsDir is per launch and not discoverable.
function Get-NppInfo{
    $exe=$null
    foreach($key in @('HKLM:\SOFTWARE\Notepad++','HKLM:\SOFTWARE\WOW6432Node\Notepad++')){
        $v=(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue).'(default)'
        if($v -and (Test-Path -LiteralPath (Join-Path $v 'notepad++.exe'))){$exe=$v;break}
    }
    if(-not $exe){$cmd=Get-Command notepad++.exe -ErrorAction SilentlyContinue;if($cmd){$exe=Split-Path $cmd.Source}}
    $portable=[bool]($exe -and (Test-Path -LiteralPath (Join-Path $exe 'doLocalConf.xml')))
    $dir=if($portable){$exe}else{Join-Path $env:APPDATA 'Notepad++'}
    $choice=Join-Path $dir 'cloud\choice';$cloud=$null
    if(Test-Path -LiteralPath $choice){$cloud=(Get-Content -LiteralPath $choice -Raw -Encoding UTF8).Trim([char]0,' ',"`r","`n")}
    [pscustomobject]@{InstallDir=$exe;Portable=$portable;SettingsDir=$dir;CloudDir=$cloud;Running=[bool](Get-Process -Name 'notepad++' -ErrorAction SilentlyContinue)}
}
# Unsaved "new N" tabs live only in backup\ and are found through absolute backupFilePath values in session.xml.
function Get-NppTabs([string]$SessionPath){
    if(-not (Test-Path -LiteralPath $SessionPath)){return @()}
    $xml=[xml](Get-Content -LiteralPath $SessionPath -Raw -Encoding UTF8)
    @(foreach($f in @($xml.SelectNodes('//File'))){
        $name=$f.GetAttribute('filename');$backup=$f.GetAttribute('backupFilePath')
        [pscustomobject]@{FileName=$name;BackupFilePath=$backup;Unsaved=-not [IO.Path]::IsPathRooted($name);HasBackup=[bool]$backup}
    })
}
# Rewrites old profile/drive prefixes in session.xml tab paths and a custom backup dir in config.xml; $null when nothing moves.
function Get-NppMappedXml([string]$Path,[string]$Relative,$Map){
    $xml=[xml](Get-Content -LiteralPath $Path -Raw -Encoding UTF8)
    $nodes=if($Relative -eq 'session.xml'){@(foreach($f in @($xml.SelectNodes('//File'))){$f.GetAttributeNode('filename');$f.GetAttributeNode('backupFilePath')})}else{@(foreach($n in @($xml.SelectNodes("//GUIConfig[@name='Backup']"))){$n.GetAttributeNode('dir')})}
    $changed=$false
    foreach($a in @($nodes|Where-Object {$_ -and $_.Value})){$v=Map-Path $a.Value $Map;if($v -ne $a.Value){$a.Value=$v;$changed=$true}}
    if(-not $changed){return $null}
    $settings=[Xml.XmlWriterSettings]::new();$settings.Encoding=$utf8;$settings.Indent=$true
    $stream=[IO.MemoryStream]::new();$writer=[Xml.XmlWriter]::Create($stream,$settings);$xml.Save($writer);$writer.Dispose()
    return ,$stream.ToArray()
}
function Get-NppFiles([string]$Root){
    @(Get-ChildItem -LiteralPath $Root -Recurse -File -Force|ForEach-Object {[pscustomobject]@{RelativePath=$_.FullName.Substring($Root.TrimEnd('\').Length+1);Bytes=$_.Length;SHA256=Hash $_.FullName}})
}
$nppRewritten=@('session.xml','config.xml')

# App settings folders. Folders are resolved from each app's own pointer where one exists.
function Get-XYplorerFolder{
    foreach($base in @($env:ProgramFiles,${env:ProgramFiles(x86)})){
        $ini=if($base){Join-Path $base 'XYplorer\Startup.ini'}
        if($ini -and (Test-Path -LiteralPath $ini)){$line=Select-String -LiteralPath $ini -Pattern '^\s*Path\s*=\s*(.+)$'|Select-Object -First 1;if($line){return [Environment]::ExpandEnvironmentVariables($line.Matches[0].Groups[1].Value.Trim())}}
    }
    return (Join-Path $env:APPDATA 'XYplorer')
}
function Get-ZoteroFolders{
    $data=Join-Path $env:USERPROFILE 'Zotero'
    $prefs=@(Get-ChildItem -LiteralPath (Join-Path $env:APPDATA 'Zotero\Zotero\Profiles') -Filter prefs.js -Recurse -File -ErrorAction SilentlyContinue)
    foreach($p in $prefs){$m=Select-String -LiteralPath $p.FullName -Pattern 'extensions\.zotero\.dataDir",\s*"(.+)"\)'|Select-Object -First 1;if($m){$data=$m.Matches[0].Groups[1].Value -replace '\\\\','\'}}
    @($data,(Join-Path $env:APPDATA 'Zotero'))
}
function Get-AppDefinitions{
    # RequireClosed: copying a live SQLite database can produce a corrupt backup.
    @(
        [pscustomobject]@{Name='XYplorer';Folders=@(Get-XYplorerFolder);Processes=@('XYplorer');RequireClosed=$false;ExcludeDirs=@()}
        [pscustomobject]@{Name='PDF-XChange';Folders=@((Join-Path $env:APPDATA 'Tracker Software'));Processes=@('PDFXEdit');RequireClosed=$false;ExcludeDirs=@()}
        [pscustomobject]@{Name='Zotero';Folders=@(Get-ZoteroFolders);Processes=@('zotero');RequireClosed=$true;ExcludeDirs=@('cache2','startupCache','crashes')}
        [pscustomobject]@{Name='PowerToys';Folders=@((Join-Path $env:LOCALAPPDATA 'Microsoft\PowerToys'));Processes=@('PowerToys');RequireClosed=$false;ExcludeDirs=@('RunnerLogs','UpdateLogs','Updates','Logs')}
    )
    foreach($extra in $ExtraAppFolder){
        $parts=$extra.Split('|')
        if($parts.Count -lt 2){throw "ExtraAppFolder must be 'Name|Folder|ProcessName': $extra"}
        [pscustomobject]@{Name=$parts[0];Folders=@([Environment]::ExpandEnvironmentVariables($parts[1]));Processes=@($parts|Select-Object -Skip 2|Where-Object {$_});RequireClosed=$false;ExcludeDirs=@()}
    }
}
function Get-AppFiles([string]$Root,[string[]]$ExcludeDirs){
    $prefix=$Root.TrimEnd('\').Length+1
    @(Get-ChildItem -LiteralPath $Root -Recurse -File -Force -ErrorAction SilentlyContinue|Where-Object {
        $dirs=@($_.FullName.Substring($prefix).Split('\')|Select-Object -SkipLast 1)
        -not @($dirs|Where-Object {$ExcludeDirs -contains $_}) -and $_.Name -notlike '*.lock' -and $_.Extension -ne '.log'
    })
}
# Old profile paths inside small UTF-8/UTF-16 text settings (plain or JSON/JS-escaped backslashes); $null when unchanged or not text.
$remapExtensions=@('.ini','.json','.js','.xml','.txt','.cfg','.config')
function Get-RemappedText([string]$Path,$Map){
    $file=Get-Item -LiteralPath $Path
    if($remapExtensions -notcontains $file.Extension.ToLower() -or $file.Length -gt 5MB){return $null}
    $bytes=[IO.File]::ReadAllBytes($Path)
    $encoding=$null;$offset=0
    if($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE){$encoding=[Text.UnicodeEncoding]::new($false,$true);$offset=2}
    elseif($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF){$encoding=[Text.UTF8Encoding]::new($true,$true);$offset=3}
    else{$encoding=[Text.UTF8Encoding]::new($false,$true)}
    try{$text=$encoding.GetString($bytes,$offset,$bytes.Length-$offset)}catch{return $null}
    $new=$text
    foreach($old in @($Map.Keys|Sort-Object Length -Descending)){
        $to=[string]$Map[$old]
        $new=[regex]::Replace($new,[regex]::Escape($old.Replace('\','\\')),$to.Replace('\','\\').Replace('$','$$'),'IgnoreCase')
        $new=[regex]::Replace($new,[regex]::Escape($old),$to.Replace('$','$$'),'IgnoreCase')
    }
    if($new -ceq $text){return $null}
    return ,([byte[]]($encoding.GetPreamble()+$encoding.GetBytes($new)))
}
function Test-Running([string[]]$Names){@($Names|Where-Object {$_ -and (Get-Process -Name $_ -ErrorAction SilentlyContinue)})}

$desktopBag='HKCU:\Software\Microsoft\Windows\Shell\Bags\1\Desktop'
function Read-DesktopBag{$key=Get-Item -LiteralPath $desktopBag -ErrorAction SilentlyContinue;if($key){Read-Values @(@{Path=$desktopBag;Names=@($key.GetValueNames())})}}
# Human reference only: minimizes windows, captures every monitor, restores the windows.
# Fonts: per-user install (no admin) = file in %LOCALAPPDATA%\Microsoft\Windows\Fonts + HKCU Fonts value.
$userFontDir=Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
$fontKey='HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts'
$fontExtensions=@('.ttf','.otf','.ttc')
function Get-FontFaces([string]$Path){
    Add-Type -AssemblyName PresentationCore
    $en=[Globalization.CultureInfo]::GetCultureInfo('en-us');$isCollection=$Path -match '\.ttc$'
    @(for($i=0;$i -lt 64;$i++){
        $uri=if($isCollection){[Uri]::new(([Uri]::new($Path)).AbsoluteUri+"#$i")}else{[Uri]::new($Path)}
        try{$g=[Windows.Media.GlyphTypeface]::new($uri)}catch{break}
        $family=$g.Win32FamilyNames[$en];if(-not $family){$family=@($g.Win32FamilyNames.Values)[0]}
        $face=$g.Win32FaceNames[$en];if(-not $face){$face=@($g.Win32FaceNames.Values)[0]}
        "$family $face"
        if(-not $isCollection){break}
    })
}
# Faces already available from system and per-user font folders.
function Get-InstalledFaces{
    $set=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($dir in @((Join-Path $env:WINDIR 'Fonts'),$userFontDir)){
        foreach($file in @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue|Where-Object {$fontExtensions -contains $_.Extension.ToLower()})){foreach($face in Get-FontFaces $file.FullName){$null=$set.Add($face)}}
    }
    return ,$set
}
function Get-FontFiles([string]$Root){@(Get-ChildItem -LiteralPath $Root -Recurse -File -Force|Where-Object {$fontExtensions -contains $_.Extension.ToLower()})}
function Read-FontRegistry{$key=Get-Item -LiteralPath $fontKey -ErrorAction SilentlyContinue;if($key){foreach($n in $key.GetValueNames()){[pscustomobject]@{Name=$n;Data=[string]$key.GetValue($n)}}}}
# Copies one font file into the per-user font folder and registers it; returns the result word.
function Install-UserFont([string]$From,[string]$RegistryName){
    $dest=Join-Path $userFontDir (Split-Path $From -Leaf)
    if((Test-Path -LiteralPath $dest) -and (Hash $dest) -ne (Hash $From)){throw "A different font file named $(Split-Path $From -Leaf) is already installed"}
    New-Item -ItemType Directory -Path $userFontDir -Force|Out-Null
    if(-not (Test-Path -LiteralPath $dest)){Copy-Item -LiteralPath $From -Destination $dest}
    if(-not (Get-Item -LiteralPath $fontKey -ErrorAction SilentlyContinue)){New-Item -Path $fontKey -Force|Out-Null}
    New-ItemProperty -LiteralPath $fontKey -Name $RegistryName -PropertyType String -Value $dest -Force|Out-Null
    if(-not ('FontApi' -as [type])){Add-Type -Namespace '' -Name FontApi -MemberDefinition '[DllImport("gdi32.dll",CharSet=CharSet.Unicode)] public static extern int AddFontResourceW(string f); [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h,uint m,IntPtr w,IntPtr l,uint f,uint t,out IntPtr r);'}
    # Makes the font usable in this logon session without signing out.
    $null=[FontApi]::AddFontResourceW($dest)
    return $dest
}
function Send-FontChange{if('FontApi' -as [type]){$r=[IntPtr]::Zero;$null=[FontApi]::SendMessageTimeout([IntPtr]0xffff,0x1D,[IntPtr]::Zero,[IntPtr]::Zero,2,1000,[ref]$r)}}
function Get-FontRegistryName([string]$Path){$faces=@(Get-FontFaces $Path|ForEach-Object {$_ -replace ' Regular$',''});$label=if($faces){$faces -join ' & '}else{[IO.Path]::GetFileNameWithoutExtension($Path)};"$label (TrueType)"}

function Save-DesktopScreenshot([string]$Path){
    Add-Type -AssemblyName System.Windows.Forms,System.Drawing
    if(-not ('DpiAware' -as [type])){Add-Type -Namespace '' -Name DpiAware -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'}
    [void][DpiAware]::SetProcessDPIAware()
    $shell=New-Object -ComObject Shell.Application
    $shell.MinimizeAll();Start-Sleep -Milliseconds 1500
    try{
        $b=[Windows.Forms.SystemInformation]::VirtualScreen
        $bmp=[Drawing.Bitmap]::new($b.Width,$b.Height);$g=[Drawing.Graphics]::FromImage($bmp)
        try{$g.CopyFromScreen($b.Left,$b.Top,0,0,$b.Size);$bmp.Save($Path,[Drawing.Imaging.ImageFormat]::Png)}finally{$g.Dispose();$bmp.Dispose()}
    }finally{$shell.UndoMinimizeAll()}
}

if($Mode -eq 'Collect'){
    if(-not $OutputDirectory){throw '-OutputDirectory required'}
    $root=[IO.Path]::GetFullPath($OutputDirectory)
    if(Test-Path -LiteralPath $root){throw 'Use a new output directory; existing snapshots will not be overwritten'}
    New-Item -ItemType Directory -Path $root|Out-Null
    $summary=[ordered]@{SchemaVersion=1;CapturedAt=$now;Computer=$env:COMPUTERNAME;User=$env:USERNAME;Profile=$env:USERPROFILE;AppData=$env:APPDATA;LocalAppData=$env:LOCALAPPDATA;Documents=$documents;OSBuild=[Environment]::OSVersion.Version.ToString();Categories=[ordered]@{}}
    foreach($c in $Category){
        $dir=Join-Path $root $c;New-Item -ItemType Directory -Path $dir|Out-Null
        try{
            switch($c){
                'StartMenu'{
                    $files=@(foreach($name in @('start.bin','start1.bin','start2.bin')){$f=Join-Path $startState $name;if(Test-Path -LiteralPath $f){Copy-Item -LiteralPath $f -Destination $dir;$name}})
                    $pins=Get-StartPins (Join-Path $dir 'start-layout.json')
                    Save-Json (Join-Path $dir 'registry.json') @(Read-Values $registrySpecs.StartMenu)
                    Save-Json (Join-Path $dir 'start-apps.json') @(Get-StartApps|Select-Object Name,AppID)
                    $summary.Categories[$c]=[ordered]@{Success=$true;LayoutFiles=$files;PinnedCount=if($null -ne $pins){$pins.Count}else{$null};PinnedList=$pins}
                }
                'Taskbar'{
                    $pinDir=Join-Path $dir 'pins';New-Item -ItemType Directory -Path $pinDir|Out-Null
                    $pins=Get-TaskbarPins
                    foreach($p in $pins){Copy-Item -LiteralPath (Join-Path $taskbarPins $p.File) -Destination $pinDir}
                    Save-Json (Join-Path $dir 'pins.json') @($pins)
                    Save-Json (Join-Path $dir 'registry.json') @(Read-Values $registrySpecs.Taskbar)
                    Save-Json (Join-Path $dir 'taskband.json') @(Read-Values @(@{Path=$taskbandPath;Names=$taskbandNames}))
                    Save-Json (Join-Path $dir 'tray-icons.json') @(Get-TrayIcons)
                    $summary.Categories[$c]=[ordered]@{Success=$true;PinCount=$pins.Count;AutoHide=Get-AutoHide}
                }
                'OfficeTemplates'{
                    $versions=Get-OfficeVersions
                    $values=@(Read-Values (Office-Specs $versions))
                    Save-Json (Join-Path $dir 'registry.json') $values
                    $roots=Get-OfficeRoots $values;$list=[Collections.Generic.List[object]]::new()
                    foreach($key in $roots.Keys){
                        $spec=$roots[$key]
                        foreach($file in Office-Files $spec.Path $spec){
                            $relative=$file.FullName.Substring($spec.Path.TrimEnd('\').Length+1)
                            $dest=Join-Path (Join-Path $dir "files\$key") $relative
                            New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null
                            Copy-Item -LiteralPath $file.FullName -Destination $dest
                            $list.Add([pscustomobject]@{Root=$key;RelativePath=$relative;Bytes=$file.Length;SHA256=Hash $dest})
                        }
                    }
                    $rootInfo=[ordered]@{};foreach($key in $roots.Keys){$rootInfo[$key]=[ordered]@{Path=$roots[$key].Path;Policy=$roots[$key].Policy;Exists=(Test-Path -LiteralPath $roots[$key].Path);ConfiguredBy=$roots[$key].ConfiguredBy}}
                    Save-Json (Join-Path $dir 'files.json') @($list)
                    $summary.Categories[$c]=[ordered]@{Success=$true;OfficeVersions=$versions;Roots=$rootInfo;FileCount=$list.Count;RegistryValueCount=$values.Count}
                }
                'QuickAccess'{
                    $items=@(Get-QuickAccess)
                    Save-Json (Join-Path $dir 'quick-access.json') $items
                    if(Test-Path -LiteralPath $quickAccessFile){Copy-Item -LiteralPath $quickAccessFile -Destination $dir}
                    $summary.Categories[$c]=[ordered]@{Success=$true;PinnedPaths=@($items|Where-Object Pinned|ForEach-Object Path);RawJumpListCopied=(Test-Path -LiteralPath $quickAccessFile)}
                }
                'NotepadPlusPlus'{
                    $npp=Get-NppInfo
                    if(-not (Test-Path -LiteralPath $npp.SettingsDir)){throw "Notepad++ settings folder not found: $($npp.SettingsDir)"}
                    # A running instance snapshots every few seconds; a copy taken now can miss the last edits.
                    $settingsCopy=Join-Path $dir 'settings'
                    Copy-Item -LiteralPath $npp.SettingsDir -Destination $settingsCopy -Recurse
                    if($npp.CloudDir -and (Test-Path -LiteralPath $npp.CloudDir)){Copy-Item -LiteralPath $npp.CloudDir -Destination (Join-Path $dir 'cloud') -Recurse}
                    $files=Get-NppFiles $settingsCopy
                    $tabs=@(Get-NppTabs (Join-Path $settingsCopy 'session.xml'))
                    Save-Json (Join-Path $dir 'files.json') $files
                    Save-Json (Join-Path $dir 'session-tabs.json') $tabs
                    $external=@($tabs|Where-Object {-not $_.Unsaved}|ForEach-Object {[pscustomobject]@{Path=$_.FileName;Exists=(Test-Path -LiteralPath $_.FileName);HasBackup=$_.HasBackup}})
                    $summary.Categories[$c]=[ordered]@{Success=$true;InstallDir=$npp.InstallDir;Portable=$npp.Portable;SettingsDir=$npp.SettingsDir;CloudDir=$npp.CloudDir;RunningAtCollect=$npp.Running;FileCount=$files.Count;TabCount=$tabs.Count;UnsavedTabCount=@($tabs|Where-Object Unsaved).Count;SavedFileTabs=$external}
                }
                'AppFolders'{
                    $apps=[ordered]@{};$list=[Collections.Generic.List[object]]::new()
                    foreach($app in Get-AppDefinitions){
                        $running=Test-Running $app.Processes
                        $roots=@(for($i=0;$i -lt $app.Folders.Count;$i++){[ordered]@{Index=$i;Path=$app.Folders[$i];Exists=(Test-Path -LiteralPath $app.Folders[$i] -PathType Container)}})
                        $entry=[ordered]@{Processes=$app.Processes;RequireClosed=$app.RequireClosed;RunningAtCollect=[bool]$running;Roots=$roots;Collected=$false;FileCount=0;Bytes=0}
                        if(-not @($roots|Where-Object {$_.Exists})){$entry.Skipped='Not installed or no settings folder';$apps[$app.Name]=$entry;continue}
                        if($running -and $app.RequireClosed){$entry.Skipped="Close $($app.Name) first (live database)";$apps[$app.Name]=$entry;continue}
                        foreach($r in @($roots|Where-Object {$_.Exists})){
                            foreach($file in Get-AppFiles $r.Path $app.ExcludeDirs){
                                $rel=$file.FullName.Substring($r.Path.TrimEnd('\').Length+1)
                                $dest=Join-Path $dir "$($app.Name)\$($r.Index)\$rel"
                                New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null
                                try{Copy-Item -LiteralPath $file.FullName -Destination $dest}catch{$entry.Errors+=@("$rel : $($_.Exception.Message)");continue}
                                $list.Add([pscustomobject]@{App=$app.Name;Root=$r.Index;RelativePath=$rel;Bytes=$file.Length;SHA256=Hash $dest})
                                $entry.FileCount++;$entry.Bytes+=$file.Length
                            }
                        }
                        $entry.Collected=$true;$apps[$app.Name]=$entry
                    }
                    Save-Json (Join-Path $dir 'files.json') @($list)
                    $summary.Categories[$c]=[ordered]@{Success=$true;Apps=$apps}
                }
                'Fonts'{
                    # Per-user installed fonts plus their HKCU registration, and optional font pack folders.
                    $registry=@(Read-FontRegistry);$userFiles=[Collections.Generic.List[object]]::new()
                    if(Test-Path -LiteralPath $userFontDir){
                        New-Item -ItemType Directory -Path (Join-Path $dir 'user') -Force|Out-Null
                        foreach($file in @(Get-ChildItem -LiteralPath $userFontDir -File -Force)){
                            Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $dir 'user')
                            $names=@($registry|Where-Object {[IO.Path]::GetFileName($_.Data) -ieq $file.Name}|ForEach-Object Name)
                            $userFiles.Add([pscustomobject]@{File=$file.Name;Bytes=$file.Length;SHA256=Hash (Join-Path $dir "user\$($file.Name)");RegistryNames=$names})
                        }
                    }
                    Save-Json (Join-Path $dir 'registry.json') $registry
                    Save-Json (Join-Path $dir 'user-files.json') @($userFiles)
                    $sources=[Collections.Generic.List[object]]::new()
                    foreach($folder in $FontSource){
                        $full=[IO.Path]::GetFullPath($folder)
                        if(-not (Test-Path -LiteralPath $full -PathType Container)){throw "Font source folder not found: $full"}
                        $leaf=Split-Path $full -Leaf;$name=$leaf;$n=2;while(@($sources|Where-Object Name -eq $name)){$name="$leaf-$n";$n++}
                        $files=@(Get-FontFiles $full)
                        foreach($file in $files){$rel=$file.FullName.Substring($full.Length+1);$dest=Join-Path $dir "sources\$name\$rel";New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null;Copy-Item -LiteralPath $file.FullName -Destination $dest}
                        $sources.Add([pscustomobject]@{Name=$name;OriginalPath=$full;Files=@($files|ForEach-Object {[pscustomobject]@{RelativePath=$_.FullName.Substring($full.Length+1);SHA256=Hash $_.FullName;Faces=@(Get-FontFaces $_.FullName)}})})
                    }
                    Save-Json (Join-Path $dir 'sources.json') @($sources)
                    $summary.Categories[$c]=[ordered]@{Success=$true;UserFontCount=$userFiles.Count;UnregisteredUserFonts=@($userFiles|Where-Object {-not $_.RegistryNames}|ForEach-Object File);Sources=@($sources|ForEach-Object {[ordered]@{Name=$_.Name;OriginalPath=$_.OriginalPath;FileCount=@($_.Files).Count}})}
                }
                'DesktopIcons'{
                    $values=@(Read-DesktopBag)
                    if(-not $values){throw "Desktop icon layout not found: $desktopBag"}
                    Save-Json (Join-Path $dir 'registry.json') $values
                    $shot=$null
                    if(-not $NoScreenshot){try{Save-DesktopScreenshot (Join-Path $dir 'desktop.png');$shot='desktop.png'}catch{$shot="failed: $($_.Exception.Message)"}}
                    $summary.Categories[$c]=[ordered]@{Success=$true;ValueCount=$values.Count;DesktopItems=@(Get-ChildItem -LiteralPath ([Environment]::GetFolderPath('Desktop')),([Environment]::GetFolderPath('CommonDesktopDirectory')) -Force -ErrorAction SilentlyContinue|Where-Object Name -ne 'desktop.ini'|ForEach-Object Name);Screenshot=$shot}
                }
            }
        }catch{$summary.Categories[$c]=[ordered]@{Success=$false;Error=$_.Exception.Message}}
    }
    Save-Json (Join-Path $root 'desktop-settings.json') $summary
    [pscustomobject]@{Output=$root;Categories=($summary.Categories.Keys -join ',');Failures=@($summary.Categories.Values|Where-Object {-not $_.Success}).Count}
    return
}

if(-not $Source){throw '-Source (a collected desktop-settings folder) required'}
$src=[IO.Path]::GetFullPath($Source)
$snapshot=Read-Json (Join-Path $src 'desktop-settings.json')
$map=New-PathMap $snapshot
$actions=[Collections.Generic.List[object]]::new()
function Act([string]$Cat,[string]$Action,[string]$Target,[string]$Result,[string]$Detail){$actions.Add([pscustomobject]@{Category=$Cat;Action=$Action;Target=$Target;Result=$Result;Detail=$Detail})}
function Selected([string]$c){($Category -contains $c) -and $snapshot.Categories.$c -and $snapshot.Categories.$c.Success}
foreach($c in $Category){if(-not (Selected $c)){Act $c 'Source' $c 'MissingBackup' 'Category absent or failed in the collected snapshot'}}

if($Mode -eq 'Restore'){
    if($Apply){
        if(-not $RollbackDirectory){$RollbackDirectory=Join-Path $env:TEMP ('desktop-settings-rollback-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))}
        $RollbackDirectory=[IO.Path]::GetFullPath($RollbackDirectory)
        if($RollbackDirectory.StartsWith($src,[StringComparison]::OrdinalIgnoreCase)){throw 'Rollback directory must be outside the backup source'}
        New-Item -ItemType Directory -Path $RollbackDirectory -Force|Out-Null
    }
    function Preserve([string]$Path,[string]$Label){if($Apply -and (Test-Path -LiteralPath $Path)){$d=Join-Path $RollbackDirectory $Label;New-Item -ItemType Directory -Path (Split-Path $d) -Force|Out-Null;Copy-Item -LiteralPath $Path -Destination $d -Force}}
    function Write-Values($Entries,[string]$Cat){
        foreach($e in @($Entries|Where-Object {$null -ne $_})){
            $value=Map-Value $e $map
            $current=(Get-Item -LiteralPath $e.Path -ErrorAction SilentlyContinue)
            $exists=$current -and $current.GetValueNames() -contains $e.Name
            $existing=if($exists){$current.GetValue($e.Name,$null,'DoNotExpandEnvironmentNames')}else{$null}
            if($exists -and $e.Kind -eq 'Binary'){$existing=B64 $existing}
            if($exists -and (Plain $existing) -eq (Plain $value)){Act $Cat 'Registry' "$($e.Path)\$($e.Name)" 'AlreadySatisfied' '';continue}
            if(-not $Apply){Act $Cat 'Registry' "$($e.Path)\$($e.Name)" 'Planned' "-> $(Plain $value)";continue}
            try{
                if(-not $current){New-Item -Path $e.Path -Force|Out-Null}
                New-ItemProperty -LiteralPath $e.Path -Name $e.Name -PropertyType $e.Kind -Value (Convert-RegistryValue $e $value) -Force|Out-Null
                Act $Cat 'Registry' "$($e.Path)\$($e.Name)" 'Written' ''
            }catch{Act $Cat 'Registry' "$($e.Path)\$($e.Name)" 'Failed' $_.Exception.Message}
        }
    }
    if(Selected 'OfficeTemplates'){
        $running=@(Get-Process -Name $officeProcesses -ErrorAction SilentlyContinue)
        if($running -and $Apply){Act 'OfficeTemplates' 'Precondition' ($running.ProcessName -join ',') 'Failed' 'Close Office applications; nothing was written for this category'}
        else{
            $dir=Join-Path $src 'OfficeTemplates'
            $values=@(Read-Json (Join-Path $dir 'registry.json'))
            Write-Values $values 'OfficeTemplates'
            $roots=$snapshot.Categories.OfficeTemplates.Roots
            foreach($f in @(Read-Json (Join-Path $dir 'files.json'))){
                $root=$roots.($f.Root);$destRoot=Map-Path $root.Path $map;$dest=Join-Path $destRoot $f.RelativePath
                $from=Join-Path $dir "files\$($f.Root)\$($f.RelativePath)"
                if((Hash $from) -ne $f.SHA256){Act 'OfficeTemplates' 'CopyFile' $dest 'Failed' 'Backup file hash mismatch';continue}
                if(Test-Path -LiteralPath $dest){
                    if((Hash $dest) -eq $f.SHA256){Act 'OfficeTemplates' 'CopyFile' $dest 'AlreadySatisfied' '';continue}
                    if($root.Policy -eq 'KeepExisting'){Act 'OfficeTemplates' 'CopyFile' $dest 'KeptExisting' 'Add-in startup file already installed; newer application copy wins';continue}
                }
                if(-not $Apply){Act 'OfficeTemplates' 'CopyFile' $dest 'Planned' "from $($f.Root)";continue}
                try{Preserve $dest "OfficeTemplates\$($f.Root)\$($f.RelativePath)";New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null;Copy-Item -LiteralPath $from -Destination $dest -Force;Act 'OfficeTemplates' 'CopyFile' $dest 'Written' ''}
                catch{Act 'OfficeTemplates' 'CopyFile' $dest 'Failed' $_.Exception.Message}
            }
        }
    }
    $shellCategories=@($Category|Where-Object {$_ -in @('StartMenu','Taskbar','DesktopIcons')}|Where-Object {Selected $_})
    if($shellCategories){
        $taskbarDir=Join-Path $src 'Taskbar'
        if(Selected 'Taskbar'){
            foreach($p in @(Read-Json (Join-Path $taskbarDir 'pins.json'))){
                $target=Map-Path $p.TargetPath $map
                if($target -and -not (Test-Path -LiteralPath $target)){Act 'Taskbar' 'PinTarget' $p.File 'Pending' "Target not installed yet: $target"}
            }
        }
        if(-not $Apply){
            if(Selected 'StartMenu'){Write-Values @(Read-Json (Join-Path $src 'StartMenu\registry.json')) 'StartMenu';foreach($name in @($snapshot.Categories.StartMenu.LayoutFiles)){$dest=Join-Path $startState $name;if((Test-Path -LiteralPath $dest) -and (Hash $dest) -eq (Hash (Join-Path $src "StartMenu\$name"))){Act 'StartMenu' 'LayoutFile' $dest 'AlreadySatisfied' ''}else{Act 'StartMenu' 'LayoutFile' $dest 'Planned' 'Replaces current Start pins'}}}
            if(Selected 'Taskbar'){
                Write-Values @(Read-Json (Join-Path $taskbarDir 'registry.json')) 'Taskbar'
                $have=@(Get-TaskbarPins|ForEach-Object File)
                foreach($p in @(Read-Json (Join-Path $taskbarDir 'pins.json'))){Act 'Taskbar' 'PinFile' $p.File $(if($have -contains $p.File){'AlreadySatisfied'}else{'Planned'}) ''}
            }
            if(Selected 'DesktopIcons'){Write-Values @(Read-Json (Join-Path $src 'DesktopIcons\registry.json')) 'DesktopIcons'}
            Act 'Shell' 'RestartExplorer' 'explorer.exe' 'Planned' 'Explorer is stopped briefly so it cannot overwrite pins/registry on exit'
        }
        else{
            Get-Process -Name explorer -ErrorAction SilentlyContinue|Stop-Process -Force
            $deadline=(Get-Date).AddSeconds(5);while((Get-Process -Name explorer -ErrorAction SilentlyContinue) -and (Get-Date) -lt $deadline){Start-Sleep -Milliseconds 100}
            try{
                if(Selected 'StartMenu'){
                    Write-Values @(Read-Json (Join-Path $src 'StartMenu\registry.json')) 'StartMenu'
                    Get-Process -Name StartMenuExperienceHost -ErrorAction SilentlyContinue|Stop-Process -Force
                    foreach($name in @($snapshot.Categories.StartMenu.LayoutFiles)){
                        $dest=Join-Path $startState $name
                        try{Preserve $dest "StartMenu\$name";Copy-Item -LiteralPath (Join-Path $src "StartMenu\$name") -Destination $dest -Force;Act 'StartMenu' 'LayoutFile' $dest 'Written' 'Pins for apps not installed are dropped by Start'}
                        catch{Act 'StartMenu' 'LayoutFile' $dest 'Failed' $_.Exception.Message}
                    }
                }
                if(Selected 'Taskbar'){
                    Write-Values @(Read-Json (Join-Path $taskbarDir 'registry.json')) 'Taskbar'
                    New-Item -ItemType Directory -Path $taskbarPins -Force|Out-Null
                    foreach($file in @(Get-ChildItem -LiteralPath (Join-Path $taskbarDir 'pins') -Filter '*.lnk' -File)){
                        $dest=Join-Path $taskbarPins $file.Name
                        if((Test-Path -LiteralPath $dest) -and (Hash $dest) -eq (Hash $file.FullName)){Act 'Taskbar' 'PinFile' $dest 'AlreadySatisfied' '';continue}
                        Preserve $dest "Taskbar\pins\$($file.Name)";Copy-Item -LiteralPath $file.FullName -Destination $dest -Force;Act 'Taskbar' 'PinFile' $dest 'Written' ''
                    }
                    $band=Get-Item -LiteralPath $taskbandPath -ErrorAction SilentlyContinue
                    if($band){$rb=Join-Path $RollbackDirectory 'Taskbar\taskband-before.json';New-Item -ItemType Directory -Path (Split-Path $rb) -Force|Out-Null;Save-Json $rb @(Read-Values @(@{Path=$taskbandPath;Names=$taskbandNames}))}
                    Write-Values @(Read-Json (Join-Path $taskbarDir 'taskband.json')) 'Taskbar'
                    $autoHide=$snapshot.Categories.Taskbar.AutoHide
                    $s=(Get-ItemProperty -LiteralPath $stuckRects -ErrorAction SilentlyContinue).Settings
                    if($null -ne $autoHide -and $s -and $s.Length -gt 8){
                        $s[8]=if($autoHide){$s[8] -bor 1}else{$s[8] -band 0xFE}
                        Set-ItemProperty -LiteralPath $stuckRects -Name Settings -Value ([byte[]]$s);Act 'Taskbar' 'AutoHide' $stuckRects 'Written' "AutoHide=$autoHide"
                    }
                }
                # Explorer saves the desktop layout on exit, so it is written only while Explorer is stopped.
                if(Selected 'DesktopIcons'){Write-Values @(Read-Json (Join-Path $src 'DesktopIcons\registry.json')) 'DesktopIcons'}
            }finally{
                if(-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)){Start-Process explorer.exe}
                Start-Sleep -Seconds 3
            }
        }
        if(Selected 'Taskbar'){
            # Tray entries exist only after each app has shown its icon once; rerun later for Pending rows.
            $current=@(Get-TrayIcons)
            foreach($t in @(Read-Json (Join-Path $taskbarDir 'tray-icons.json')|Where-Object {$null -ne $_.IsPromoted})){
                $exe=Map-Path $t.ExecutablePath $map
                $match=@($current|Where-Object {$_.ExecutablePath -eq $exe})
                if(-not $match){Act 'Taskbar' 'TrayIcon' $exe 'Pending' 'App has not registered its tray icon yet';continue}
                foreach($m in $match){
                    if($m.IsPromoted -eq $t.IsPromoted){Act 'Taskbar' 'TrayIcon' $exe 'AlreadySatisfied' '';continue}
                    if(-not $Apply){Act 'Taskbar' 'TrayIcon' $exe 'Planned' "IsPromoted=$($t.IsPromoted)";continue}
                    Set-ItemProperty -LiteralPath "HKCU:\Control Panel\NotifyIconSettings\$($m.Key)" -Name IsPromoted -Value ([int]$t.IsPromoted) -Type DWord;Act 'Taskbar' 'TrayIcon' $exe 'Written' ''
                }
            }
        }
    }
    if(Selected 'QuickAccess'){
        $shell=New-Object -ComObject Shell.Application
        $current=@(Get-QuickAccess|Where-Object Pinned)
        $wanted=@(Read-Json (Join-Path $src 'QuickAccess\quick-access.json')|Where-Object Pinned|ForEach-Object {Map-Path $_.Path $map})
        foreach($path in $wanted){
            if($current.Path -contains $path){Act 'QuickAccess' 'Pin' $path 'AlreadySatisfied' '';continue}
            if(-not (Test-Path -LiteralPath $path)){Act 'QuickAccess' 'Pin' $path 'Pending' 'Path not reachable yet (restore SMB/WSL/data first, then rerun)';continue}
            if(-not $Apply){Act 'QuickAccess' 'Pin' $path 'Planned' '';continue}
            try{$shell.Namespace($path).Self.InvokeVerb('pintohome');Act 'QuickAccess' 'Pin' $path 'Written' ''}catch{Act 'QuickAccess' 'Pin' $path 'Failed' $_.Exception.Message}
        }
        if($ExactQuickAccess){
            foreach($item in @($shell.Namespace($quickAccessNamespace).Items())){
                if($item.ExtendedProperty('System.Home.IsPinned') -and $wanted -notcontains $item.Path){
                    if(-not $Apply){Act 'QuickAccess' 'Unpin' $item.Path 'Planned' 'Not pinned in backup';continue}
                    try{$item.InvokeVerb('unpinfromhome');Act 'QuickAccess' 'Unpin' $item.Path 'Written' ''}catch{Act 'QuickAccess' 'Unpin' $item.Path 'Failed' $_.Exception.Message}
                }
            }
        }
    }
    if(Selected 'AppFolders'){
        $apps=$snapshot.Categories.AppFolders.Apps;$files=@(Read-Json (Join-Path $src 'AppFolders\files.json'))
        foreach($name in @($apps.PSObject.Properties.Name)){
            $app=$apps.$name
            if(-not $app.Collected){Act 'AppFolders' 'Source' $name 'MissingBackup' $app.Skipped;continue}
            $running=Test-Running @($app.Processes)
            if($running -and $Apply){Act 'AppFolders' 'Precondition' $name 'Failed' "Close $($running -join ',') first; nothing was written for this app";continue}
            foreach($f in @($files|Where-Object App -eq $name)){
                $root=@($app.Roots|Where-Object Index -eq $f.Root)[0]
                $from=Join-Path $src "AppFolders\$name\$($f.Root)\$($f.RelativePath)";$dest=Join-Path (Map-Path $root.Path $map) $f.RelativePath
                if((Hash $from) -ne $f.SHA256){Act 'AppFolders' 'CopyFile' $dest 'Failed' 'Backup file hash mismatch';continue}
                $bytes=Get-RemappedText $from $map
                if(Test-Path -LiteralPath $dest){
                    $same=if($bytes){[Convert]::ToBase64String($bytes) -eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($dest))}else{(Hash $dest) -eq $f.SHA256}
                    if($same){Act 'AppFolders' 'CopyFile' $dest 'AlreadySatisfied' '';continue}
                }
                if(-not $Apply){Act 'AppFolders' 'CopyFile' $dest 'Planned' $(if($bytes){'paths remapped'}else{''});continue}
                try{
                    Preserve $dest "AppFolders\$name\$($f.Root)\$($f.RelativePath)";New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null
                    if($bytes){[IO.File]::WriteAllBytes($dest,$bytes)}else{Copy-Item -LiteralPath $from -Destination $dest -Force}
                    Act 'AppFolders' 'CopyFile' $dest 'Written' ''
                }catch{Act 'AppFolders' 'CopyFile' $dest 'Failed' $_.Exception.Message}
            }
        }
        $xy=$apps.XYplorer
        if($xy -and $xy.Collected -and (Get-XYplorerFolder) -ne (Map-Path $xy.Roots[0].Path $map)){Act 'AppFolders' 'Pointer' 'XYplorer\Startup.ini' 'Pending' "Install XYplorer, then point Startup.ini [Appdata] Path at $(Map-Path $xy.Roots[0].Path $map)"}
    }
    if(Selected 'Fonts'){
        $fontDir=Join-Path $src 'Fonts';$installedAny=$false
        $registry=@(Read-FontRegistry)
        foreach($f in @(Read-Json (Join-Path $fontDir 'user-files.json'))){
            $from=Join-Path $fontDir "user\$($f.File)";$dest=Join-Path $userFontDir $f.File
            if((Hash $from) -ne $f.SHA256){Act 'Fonts' 'UserFont' $f.File 'Failed' 'Backup file hash mismatch';continue}
            # A file that was unregistered originally (usually a duplicate face) is copied back but stays unregistered.
            $names=@($f.RegistryNames)
            $fileOk=(Test-Path -LiteralPath $dest) -and (Hash $dest) -eq $f.SHA256
            $regOk=-not @($names|Where-Object {$n=$_;-not @($registry|Where-Object {$_.Name -eq $n -and $_.Data -ieq $dest})})
            if($fileOk -and $regOk){Act 'Fonts' 'UserFont' $f.File 'AlreadySatisfied' '';continue}
            if(-not $Apply){Act 'Fonts' 'UserFont' $f.File 'Planned' $(if($names){$names -join '; '}else{'file only (unregistered in original)'});continue}
            try{
                if($names){foreach($n in $names){$null=Install-UserFont $from $n};$installedAny=$true}
                elseif(-not $fileOk){New-Item -ItemType Directory -Path $userFontDir -Force|Out-Null;Copy-Item -LiteralPath $from -Destination $dest -Force}
                Act 'Fonts' 'UserFont' $f.File 'Written' ''
            }catch{Act 'Fonts' 'UserFont' $f.File 'Failed' $_.Exception.Message}
        }
        $sources=@(Read-Json (Join-Path $fontDir 'sources.json'))
        if($sources){
            $faces=Get-InstalledFaces
            foreach($s in $sources){
                foreach($f in @($s.Files)){
                    $from=Join-Path $fontDir "sources\$($s.Name)\$($f.RelativePath)";$label="$($s.Name)\$($f.RelativePath)"
                    if((Hash $from) -ne $f.SHA256){Act 'Fonts' 'SourceFont' $label 'Failed' 'Backup file hash mismatch';continue}
                    $missing=@(@($f.Faces)|Where-Object {-not $faces.Contains($_)})
                    if(@($f.Faces) -and -not $missing){Act 'Fonts' 'SourceFont' $label 'AlreadySatisfied' 'Face already installed';continue}
                    if(-not $Apply){Act 'Fonts' 'SourceFont' $label 'Planned' (@($f.Faces) -join '; ');continue}
                    try{$null=Install-UserFont $from (Get-FontRegistryName $from);foreach($face in @($f.Faces)){$null=$faces.Add($face)};$installedAny=$true;Act 'Fonts' 'SourceFont' $label 'Written' (@($f.Faces) -join '; ')}
                    catch{Act 'Fonts' 'SourceFont' $label 'Failed' $_.Exception.Message}
                }
            }
        }
        if($installedAny){Send-FontChange}
    }
    if(Selected 'NotepadPlusPlus'){
        $info=$snapshot.Categories.NotepadPlusPlus;$npp=Get-NppInfo
        $destRoot=if($info.Portable){Map-Path $info.SettingsDir $map}else{Join-Path $env:APPDATA 'Notepad++'}
        if(-not $npp.InstallDir){Act 'NotepadPlusPlus' 'Install' 'notepad++.exe' 'Pending' 'Notepad++ not installed yet; settings can be placed first, install before Verify'}
        if($npp.Running -and $Apply){Act 'NotepadPlusPlus' 'Precondition' 'notepad++.exe' 'Failed' 'Close every Notepad++ window; it rewrites session.xml/config.xml on exit. Nothing was written'}
        else{
            $settingsSrc=Join-Path $src 'NotepadPlusPlus\settings'
            foreach($f in @(Read-Json (Join-Path $src 'NotepadPlusPlus\files.json'))){
                $from=Join-Path $settingsSrc $f.RelativePath;$dest=Join-Path $destRoot $f.RelativePath
                if((Hash $from) -ne $f.SHA256){Act 'NotepadPlusPlus' 'CopyFile' $dest 'Failed' 'Backup file hash mismatch';continue}
                $bytes=if($nppRewritten -contains $f.RelativePath){Get-NppMappedXml $from $f.RelativePath $map}else{$null}
                if(Test-Path -LiteralPath $dest){
                    $same=if($bytes){[Convert]::ToBase64String($bytes) -eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($dest))}else{(Hash $dest) -eq $f.SHA256}
                    if($same){Act 'NotepadPlusPlus' 'CopyFile' $dest 'AlreadySatisfied' '';continue}
                }
                if(-not $Apply){Act 'NotepadPlusPlus' 'CopyFile' $dest 'Planned' $(if($bytes){'paths remapped'}else{''});continue}
                try{
                    Preserve $dest "NotepadPlusPlus\$($f.RelativePath)";New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null
                    if($bytes){[IO.File]::WriteAllBytes($dest,$bytes)}else{Copy-Item -LiteralPath $from -Destination $dest -Force}
                    Act 'NotepadPlusPlus' 'CopyFile' $dest 'Written' ''
                }catch{Act 'NotepadPlusPlus' 'CopyFile' $dest 'Failed' $_.Exception.Message}
            }
            if($info.CloudDir){Act 'NotepadPlusPlus' 'CloudDir' $info.CloudDir 'Pending' 'Cloud settings folder: restore/sync it, then reselect it in Preferences > Cloud & Link (copy kept under NotepadPlusPlus\cloud)'}
            foreach($t in @($info.SavedFileTabs)){
                $path=Map-Path $t.Path $map
                if(-not (Test-Path -LiteralPath $path)){Act 'NotepadPlusPlus' 'SavedFileTab' $path 'Pending' 'Tab refers to a saved document outside the Notepad++ folder; restore that file (unsaved edits, if any, are in backup\)'}
            }
        }
    }
    $report=[ordered]@{Mode='Restore';Applied=[bool]$Apply;CheckedAt=$now;Source=$src;RollbackDirectory=$RollbackDirectory;PathMap=$map;Actions=@($actions)}
    if($ResultPath){Save-Json ([IO.Path]::GetFullPath($ResultPath)) $report}
    $actions|Group-Object Category,Result|ForEach-Object {[pscustomobject]@{Group=$_.Name;Count=$_.Count}}
    if(-not $Apply){Write-Host 'Preview only; rerun with -Apply to write. Pending rows need prerequisites (apps, SMB, WSL) and a later rerun.'}
    return
}

# Verify: current observations against the backup; restore-contract Settings dimension per category.
$items=[Collections.Generic.List[object]]::new()
function Compare-Values($Entries){
    @(foreach($e in @($Entries|Where-Object {$null -ne $_})){
        $want=Plain (Map-Value $e $map)
        $key=Get-Item -LiteralPath $e.Path -ErrorAction SilentlyContinue
        $have=if($key -and $key.GetValueNames() -contains $e.Name){$v=$key.GetValue($e.Name,$null,'DoNotExpandEnvironmentNames');if($e.Kind -eq 'Binary'){B64 $v}else{Plain $v}}else{$null}
        if($have -ne $want){"$($e.Path)\$($e.Name): expected '$want', found '$have'"}
    })
}
function Add-Item([string]$Id,[string[]]$Problems,[string[]]$Pending){
    $status=if($Problems){'Partial'}elseif($Pending){'Partial'}else{'Verified'}
    $items.Add([ordered]@{Id=$Id;Settings=[ordered]@{Status=$status;CheckedAt=$now;Evidence=if($Problems -or $Pending){(@($Problems)+@($Pending|ForEach-Object {"pending: $_"})) -join '; '}else{'All recorded values and items present'}}})
}
foreach($c in $Category){
    if(-not (Selected $c)){$items.Add([ordered]@{Id="desktop-$($c.ToLower())";Settings=[ordered]@{Status='MissingBackup';CheckedAt=$now;Evidence='Category absent or failed in snapshot'}});continue}
    switch($c){
        'StartMenu'{
            $problems=@(Compare-Values (Read-Json (Join-Path $src 'StartMenu\registry.json')))
            $tmp=Join-Path $env:TEMP ("start-layout-verify-$PID.json");$pins=Get-StartPins $tmp;Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
            $missing=@()
            if($null -ne $pins -and $snapshot.Categories.StartMenu.PinnedList){$missing=@($snapshot.Categories.StartMenu.PinnedList|ForEach-Object {Map-Path $_ $map}|Where-Object {$pins -notcontains $_})}
            Add-Item 'desktop-startmenu' $problems @($missing|ForEach-Object {"start pin $_"})
        }
        'Taskbar'{
            $dir=Join-Path $src 'Taskbar'
            $problems=@(Compare-Values (Read-Json (Join-Path $dir 'registry.json')))
            $have=@(Get-TaskbarPins|ForEach-Object File)
            $missing=@(Read-Json (Join-Path $dir 'pins.json')|Where-Object {$have -notcontains $_.File}|ForEach-Object {"taskbar pin $($_.File)"})
            $hide=$snapshot.Categories.Taskbar.AutoHide;if($null -ne $hide -and (Get-AutoHide) -ne $hide){$problems+="AutoHide expected $hide"}
            $tray=@(Get-TrayIcons);$trayPending=@()
            foreach($t in @(Read-Json (Join-Path $dir 'tray-icons.json')|Where-Object {$null -ne $_.IsPromoted})){
                $exe=Map-Path $t.ExecutablePath $map;$m=@($tray|Where-Object {$_.ExecutablePath -eq $exe})
                if(-not $m){$trayPending+="tray $exe"}elseif(@($m|Where-Object {$_.IsPromoted -ne $t.IsPromoted})){$problems+="tray $exe IsPromoted expected $($t.IsPromoted)"}
            }
            Add-Item 'desktop-taskbar' $problems (@($missing)+@($trayPending))
        }
        'OfficeTemplates'{
            $dir=Join-Path $src 'OfficeTemplates'
            $problems=@(Compare-Values (Read-Json (Join-Path $dir 'registry.json')))
            $roots=$snapshot.Categories.OfficeTemplates.Roots
            foreach($f in @(Read-Json (Join-Path $dir 'files.json'))){
                $root=$roots.($f.Root);$dest=Join-Path (Map-Path $root.Path $map) $f.RelativePath
                if(-not (Test-Path -LiteralPath $dest)){$problems+="missing $dest"}
                elseif($root.Policy -ne 'KeepExisting' -and (Hash $dest) -ne $f.SHA256){$problems+="changed $dest"}
            }
            Add-Item 'desktop-office-templates' $problems @()
        }
        'QuickAccess'{
            $have=@(Get-QuickAccess|Where-Object Pinned|ForEach-Object Path)
            $wanted=@(Read-Json (Join-Path $src 'QuickAccess\quick-access.json')|Where-Object Pinned|ForEach-Object {Map-Path $_.Path $map})
            $missing=@($wanted|Where-Object {$have -notcontains $_}|ForEach-Object {"quick access $_"})
            $extra=@($have|Where-Object {$wanted -notcontains $_})
            Add-Item 'desktop-quickaccess' $missing @()
            if($extra){$items[$items.Count-1].Settings.Extra=$extra}
        }
        'NotepadPlusPlus'{
            $info=$snapshot.Categories.NotepadPlusPlus;$npp=Get-NppInfo;$problems=@();$pending=@()
            $destRoot=if($info.Portable){Map-Path $info.SettingsDir $map}else{Join-Path $env:APPDATA 'Notepad++'}
            if(-not $npp.InstallDir){$problems+='notepad++.exe not installed'}
            # session.xml/config.xml and backup\ legitimately change once Notepad++ is used; check tabs instead of hashes.
            foreach($f in @(Read-Json (Join-Path $src 'NotepadPlusPlus\files.json')|Where-Object {$nppRewritten -notcontains $_.RelativePath -and $_.RelativePath -notlike 'backup\*'})){
                $dest=Join-Path $destRoot $f.RelativePath
                if(-not (Test-Path -LiteralPath $dest)){$problems+="missing $dest"}elseif((Hash $dest) -ne $f.SHA256){$problems+="changed $dest"}
            }
            $current=@(Get-NppTabs (Join-Path $destRoot 'session.xml'))
            foreach($t in @(Read-Json (Join-Path $src 'NotepadPlusPlus\session-tabs.json')|Where-Object Unsaved)){
                $m=@($current|Where-Object {$_.FileName -eq $t.FileName})
                if(-not $m){$problems+="unsaved tab '$($t.FileName)' missing from session"}
                elseif(@($m|Where-Object {$_.HasBackup -and -not (Test-Path -LiteralPath $_.BackupFilePath)})){$problems+="unsaved tab '$($t.FileName)' backup file missing"}
            }
            foreach($t in @($info.SavedFileTabs)){$p=Map-Path $t.Path $map;if(-not (Test-Path -LiteralPath $p)){$pending+="saved document $p"}}
            Add-Item 'desktop-notepadplusplus' $problems $pending
        }
        'AppFolders'{
            $apps=$snapshot.Categories.AppFolders.Apps;$files=@(Read-Json (Join-Path $src 'AppFolders\files.json'));$problems=@();$pending=@()
            foreach($name in @($apps.PSObject.Properties.Name)){
                $app=$apps.$name
                if(-not $app.Collected){if(@($app.Roots|Where-Object Exists)){$problems+="$name not backed up: $($app.Skipped)"};continue}
                foreach($f in @($files|Where-Object App -eq $name)){
                    $root=@($app.Roots|Where-Object Index -eq $f.Root)[0];$dest=Join-Path (Map-Path $root.Path $map) $f.RelativePath
                    if(-not (Test-Path -LiteralPath $dest)){$problems+="missing $dest";continue}
                    # Apps rewrite their own settings once launched; remapped text is checked for presence only.
                    if(-not (Get-RemappedText (Join-Path $src "AppFolders\$name\$($f.Root)\$($f.RelativePath)") $map) -and (Hash $dest) -ne $f.SHA256){$pending+="changed since backup $dest"}
                }
            }
            Add-Item 'desktop-appfolders' $problems $pending
        }
        'DesktopIcons'{
            $problems=@(Compare-Values (Read-Json (Join-Path $src 'DesktopIcons\registry.json')))
            $desk=@(Get-ChildItem -LiteralPath ([Environment]::GetFolderPath('Desktop')),([Environment]::GetFolderPath('CommonDesktopDirectory')) -Force -ErrorAction SilentlyContinue|ForEach-Object Name)
            $missing=@($snapshot.Categories.DesktopIcons.DesktopItems|Where-Object {$desk -notcontains $_}|ForEach-Object {"desktop item $_"})
            Add-Item 'desktop-desktopicons' $problems $missing
        }
        'Fonts'{
            $fontDir=Join-Path $src 'Fonts';$problems=@();$registry=@(Read-FontRegistry)
            foreach($f in @(Read-Json (Join-Path $fontDir 'user-files.json'))){
                $dest=Join-Path $userFontDir $f.File
                if(-not (Test-Path -LiteralPath $dest)){$problems+="missing font $($f.File)";continue}
                if((Hash $dest) -ne $f.SHA256){$problems+="different font file $($f.File)"}
                foreach($n in @($f.RegistryNames)){if(-not @($registry|Where-Object {$_.Name -eq $n -and $_.Data -ieq $dest})){$problems+="font not registered: $n"}}
            }
            $sources=@(Read-Json (Join-Path $fontDir 'sources.json'))
            if($sources){
                $faces=Get-InstalledFaces
                foreach($s in $sources){foreach($f in @($s.Files)){foreach($face in @($f.Faces)){if(-not $faces.Contains($face)){$problems+="font face not installed: $face ($($s.Name))"}}}}
            }
            Add-Item 'desktop-fonts' $problems @()
        }
    }
}
$result=[ordered]@{SchemaVersion=2;VerifiedAt=$now;Source=$src;Context=[ordered]@{Identity=[Security.Principal.WindowsIdentity]::GetCurrent().Name;SessionId=[Diagnostics.Process]::GetCurrentProcess().SessionId};Items=@($items)}
if($ResultPath){Save-Json ([IO.Path]::GetFullPath($ResultPath)) $result}
$items|ForEach-Object {[pscustomobject]@{Id=$_.Id;Status=$_.Settings.Status;Evidence=$_.Settings.Evidence}}
