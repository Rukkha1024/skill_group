---
name: windows-preformat-backup
description: "Prepare, review, or restore Windows pre-format environment backups covering applications, Codex/Claude settings, SMB, WSL, and SSH; verify restored behavior and clean owned temporary artifacts. Use for Windows reinstall preparation or restoration from a backup bundle, not disk formatting or automatic backup of all personal data."
---

# Windows pre-format environment backup

Create an evidence-backed, portable restore bundle, not just a conversation summary. Preserve the distinction between installed-state history, the user's desired post-format environment, and backed-up file contents.

## Scope and saved preferences

Read [user-defaults.md](references/user-defaults.md) at the start. These are this user's defaults, not universal requirements; explicit instructions in the current conversation override them. Determine whether the request is **prepare**, **review**, or **restore**. Review/status requests do not themselves authorize reinstalling programs or changing live network settings.

Keep existing session authorization through installation, reboot continuation and verification. Do not ask again for routine steps already authorized. A missing password, login, license or unavailable backup blocks only its own item; continue independent work and report the actual gap.

Inspect the actual current Windows profile, volumes, physical disks, WSL registrations and tools. Do not carry forward a previous computer name, username, drive letter, share address, distro count, package count, or version as a current fact.

Resolve a durable destination before declaring the work complete. Use the user's named location, or the saved preferred drive if it still exists and is suitable. Read disk/partition metadata: a different drive letter does not establish a different physical disk. A staging copy on the disk being erased is not the final backup. Never format or repartition as part of this skill.

Check filesystem capabilities before large/confidential writes: FAT32 limits each file to 4 GiB minus 1 byte and does not provide NTFS private-key ACLs. Full WSL exports can contain credentials too; protect/encrypt their destination before creating them. Resolve an appropriate destination or explicit encrypted/segmented recovery method where these constraints are real, while continuing independent metadata collection.

## Prepare

1. Collect original metadata into a new timestamped snapshot. Preserve previous snapshots. `scripts/collect-windows.ps1 -OutputDirectory <new-inventory-folder>` collects Windows/SMB/WSL-registration metadata. Add `-IncludePackageManagers` for supported package-manager inventories; inspect `collection-status.json` and fill required gaps.
2. Collect each in-scope WSL distro separately using `scripts/collect-wsl.sh <new-output-folder> [linux-home]`. Prefer a non-login Bash invocation; inspect user-home package managers explicitly rather than depending on shell startup files. Read [wsl-and-ssh.md](references/wsl-and-ssh.md) for distribution export/verification and SSH private backups.
3. Build a human Windows reinstall list with Korean and official English names paired, verified official download/product/install URLs, and original names, package IDs, observed versions and evidence in an accompanying JSON/CSV. Respect user-managed/excluded apps without deleting their historical evidence. Classify duplicate uninstall entries, SDK/runtime components, built-in apps, driver bundles and manually installed/portable programs rather than treating every row as a separate user app. Capture Python/Conda, npm and VS Code extensions where present and relevant.
4. Record saved and active drive mappings independently. Include disconnected `HKCU\Network` entries, local WSL/Plan 9 mappings, SMB signing/encryption/guest/protocol values, share permissions, relevant firewall scope, services, network profiles and Tailscale dependencies. No saved password extraction. Metadata is not a successful authentication test.
5. When full WSL export or SSH backup is requested or already authorized in the session, perform it within that scope. Keep private SSH payloads out of the ordinary program-list archive; protect the destination before copying. Inspect Windows and Linux SSH independently. Follow external `IdentityFile`/`Include` references and report unresolved coverage.
6. Write the **desired restore target** separately from original inventories. A full WSL import restores old extra tools too. If the user wants a fresh minimal WSL, keep the full export as a recovery source and do not make it the default setup.
   Include installed AI tools' settings as a separate coverage category. Read [agent-settings.md](references/agent-settings.md); collect Windows and each WSL separately, including referenced role, instruction, hook and enabled-plugin files. A WSL export excludes mounted Windows data. Missing settings/dependencies must appear in the pre-format coverage report; executable inventories are not settings backups.
7. Produce human-facing guides with Korean filenames, for example `00_먼저_읽어주세요.txt` and `01_포맷후_Codex에_붙여넣기.txt`, in a separate Korean-named folder. Provide a clearly identified user-install list as well as the structured Codex restore target, scope/coverage report, checksums and metadata archive. English technical filenames may remain in the machine inventory area. Copy the verification helper into the deliverable. Use [bundle-and-restore.md](references/bundle-and-restore.md) for program responsibility categories, layout, invariants and restore behavior.

## Review and verify

- Compare recorded metadata with live state only on the original machine. Distinguish background version/index changes from missing programs; preserve the original snapshot and record newer observations separately.
- Infer executable presence from existence/resolved links and package metadata. Do not run arbitrary agent `--version` commands: some self-update even on a version query. Use an executable's static version resource, installation directory, npm package manifest or prior captured evidence, and mark unknowns.
- Validate JSON/YAML, recorded IDs versus actual package-manager IDs, Windows/Linux package separation and target exclusions. An Ubuntu Store app version is not the Linux OS version; `<`/`>` version displays are not literal installer versions. Do not blindly import a raw winget export.
- Check the human program list against the structured target: paired Korean/English names, official URL and verification status, and install responsibility must agree. User-managed exclusions must not reappear through a raw package import or full WSL import. Repeated review requests require a consistency/coverage check, not a claim that every historical package should be restored.
- Generate `RelativePath,Bytes,SHA256` CSV manifests only after finishing edits. `scripts/verify-manifest.ps1 -Root <bundle-root> -Manifest <csv-path>` works without WSL or the original computer. It rejects missing, modified and escaping entries. Keep hashes for large tar/private archives at the snapshot root and verify from their actual moved locations.
- Verify full exports with exit status, size, SHA-256 and archive members. A separate temporary WSL import adds confidence when proportionate. Compare meaningful files/permissions/data counts, record the comparison limits, and identify the exact new registration/path before cleanup. Never unregister an existing user distro as a test step.
- After final edits, regenerate affected manifests and archives; compare archive members against the source. Report what is actually verified, what was skipped, remaining credentials/licenses, and data outside scope. Do not call a directory with only installation lists a personal-data backup.

## Restore

Read the archived target and latest user instructions first; do not recollect over the backup. Resolve actual current locations and verify immutable inputs before installing. Apply the desired target, skip already satisfied items, and keep resumable per-item results outside the source snapshot. Relevant detail is in [bundle-and-restore.md](references/bundle-and-restore.md) and [wsl-and-ssh.md](references/wsl-and-ssh.md).

Use [restore-contract.md](references/restore-contract.md) for versioned targets, precedence, per-dimension status and evidence. Verify installation, settings, authentication and functional behavior independently. Do not call restoration complete while requested settings or connections are missing. A report must use current observations, not success records from before a reboot, sync or later modification.

Keep work in one session-owned directory under the local temporary directory, or a deliberately chosen working directory for large files. Never scatter diagnostic scripts/screenshots at a drive root. Register owned artifacts in a work journal. Read the completion/cleanup section in [bundle-and-restore.md](references/bundle-and-restore.md) before handoff; relocate useful records and reconnect tools, verify their dependencies, then clean only registered temporary artifacts.

Reusable helpers are preview-first: `agent-settings.py` collects/restores private settings and verifies their graph/MCP initialization; `restore-state.py` normalizes legacy targets and validates evidence; `verify-restore.ps1` checks current desktop mappings, Python/extension exclusions and optional SSH identities; `cleanup-restore.ps1` checks and deletes journaled work only with `-Apply`; `connect-smb.ps1` is a portable desktop-user reconnect tool. Read each helper's linked reference/usage before applying it.

## Keep the skill through the format

The installed skill itself may be on the disk being erased. Save a clean copy/ZIP of this skill to the durable destination, excluding test fixtures, live inventories, keys, credentials and caches. After reinstall, restore its folder to the current `$CODEX_HOME/skills` or `%USERPROFILE%\.codex\skills`. If a same-named skill already exists, inspect and preserve unrelated changes.
