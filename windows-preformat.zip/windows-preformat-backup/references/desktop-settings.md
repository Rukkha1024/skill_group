# Desktop personalization: Start, taskbar, Office templates, Quick Access, Notepad++, app folders, desktop icons

`scripts/desktop-settings.ps1` covers seven categories. Run it as the desktop user (non-elevated), because every value lives in that user's HKCU/profile.

| Category | Collected payload | Restore method |
| --- | --- | --- |
| `StartMenu` | `start*.bin` from `StartMenuExperienceHost\LocalState`, `Export-StartLayout` JSON (readable pin list), `Get-StartApps`, allowlisted `Start_*` and `...\Start` values (recommendations, recent/frequent lists, folders beside power button, all-apps view) | Copy `start2.bin` while Explorer and Start host are stopped; write values |
| `Taskbar` | Pinned `.lnk` files from `User Pinned\TaskBar`, resolved targets, `Taskband` pin-order blobs, alignment/widgets/task view/search box/grouping/multi-monitor/End task values, auto-hide bit from `StuckRects3`, tray `NotifyIconSettings` `IsPromoted` per executable | Copy pins and blobs with Explorer stopped; set tray promotion by matching `ExecutablePath` |
| `OfficeTemplates` | `%APPDATA%\Microsoft\Templates` (Normal.dotm, blank.potx, Document Themes...), `Documents\Custom Office Templates`, Word `STARTUP`, Excel `XLSTART`, ribbon/QAT `*.officeUI`, any local folder set by `PersonalTemplates`/`UserTemplates`/`STARTUP-PATH`/`AltStartup`; those registry values for each `HKCU\Software\Microsoft\Office\<ver>` | Copy files with path mapping; write template-location values |
| `NotepadPlusPlus` | The whole settings folder: `%APPDATA%\Notepad++` (or the install folder when `doLocalConf.xml` makes it portable), including `session.xml` (open tabs), `backup\` (unsaved `new N` tabs and unsaved edits from session snapshot), `config.xml`, `shortcuts.xml` (macros/run commands), `stylers.xml`, `themes\`, `userDefineLangs\`, `plugins\` configs; a copy of the cloud settings folder when one is selected | Copy the folder back with Notepad++ closed; rewrite absolute `filename`/`backupFilePath` paths in `session.xml` (and a custom backup `dir` in `config.xml`) when the profile path or drive changed |
| `AppFolders` | Settings/data folders of registered apps: XYplorer (folder read from `Program Files\XYplorer\Startup.ini`), PDF-XChange (`%APPDATA%\Tracker Software`), Zotero (data folder from `prefs.js` `dataDir`, default `~\Zotero`, plus `%APPDATA%\Zotero` profile), PowerToys (`%LOCALAPPDATA%\Microsoft\PowerToys`); extra apps via `-ExtraAppFolder 'Name|Folder|Process'`. Logs, `*.log`, lock files and app caches are skipped | Copy back per app while that app is closed; old profile paths inside small UTF-8/UTF-16 `.ini/.json/.js/.xml/.txt/.cfg/.config` files are rewritten (plain and `\\`-escaped) |
| `DesktopIcons` | All values of `HKCU\Software\Microsoft\Windows\Shell\Bags\1\Desktop` (`IconLayouts` positions, auto-arrange/grid flags, icon size, sort), the desktop item names, and `desktop.png` (all monitors, windows minimized for ~1.5 s; skip with `-NoScreenshot`) | Write values with Explorer stopped; the PNG is a human reference only |
| `QuickAccess` | Pinned items from the Quick Access/Home namespace (`System.Home.IsPinned`) and the raw `f01b4d95cf55d32a.automaticDestinations-ms` jump list as a fallback | `pintohome` verb per mapped path; add-only unless `-ExactQuickAccess` |

Excluded on purpose: Office `LiveContent` (Microsoft downloads it again), `~$*` lock files, network template folders (record only), and Explorer view/global options outside this allowlist. Do not widen the allowlist silently; add values when the user asks.

## Usage

```powershell
# Prepare (new folder; never overwrites)
scripts\desktop-settings.ps1 -Mode Collect -OutputDirectory <snapshot>\desktop-settings
# Restore: preview, then apply
scripts\desktop-settings.ps1 -Mode Restore -Source <snapshot>\desktop-settings -ResultPath <work>\desktop-restore.json
scripts\desktop-settings.ps1 -Mode Restore -Source ... -Apply -RollbackDirectory <work>\desktop-rollback -ResultPath ...
# Verify (read-only; restore-contract Settings dimension per category)
scripts\desktop-settings.ps1 -Mode Verify -Source ... -ResultPath <work>\desktop-verify.json
```

`-Category` limits the run (`StartMenu`, `Taskbar`, `OfficeTemplates`, `QuickAccess`, `NotepadPlusPlus`, `AppFolders`, `DesktopIcons`). Old profile, AppData, LocalAppData and Documents prefixes are mapped to the current ones automatically (OneDrive-redirected Documents included). Add `-PathMap @{'Y:\'='Z:\'}` when a drive letter or share changed; explicit entries win.

## Ordering and non-obvious behavior

- Restore **after** applications, SMB mappings, WSL and personal data are back. Start drops pins for apps that are not installed; Quick Access paths on `Y:` or `\\wsl.localhost\...` are `Pending` until reachable; tray rows are `Pending` until each app has shown its icon once. Rerun Restore for Pending rows instead of declaring success.
- Taskbar/Start apply stops `explorer.exe` briefly. Explorer rewrites `Taskband` on exit, so writing while it runs is lost. Close the user's open Explorer windows first and tell the user the taskbar will blink. The script restarts Explorer if Windows has not already done so.
- `start2.bin` and `Taskband` blobs are build-dependent binary formats. Same-major-build restores normally work; if Verify reports missing Start pins after a large Windows version jump, pin the listed apps from `start-layout.json` by hand and report the substitution.
- Some builds protect `TaskbarDa` (widgets) through the User Choice Protection Driver. A `Failed` registry write there is a reported gap, not a reason to disable protection.
- Office apply refuses while Word/PowerPoint/Excel/Outlook run. Existing differing files go to the rollback directory before replacement. Startup add-ins (Word `STARTUP`, `XLSTART`) keep an already installed copy because a reinstalled add-in (e.g. Zotero) is newer; report `KeptExisting`.
- Quick Access restore preserves backup order only for paths pinned in the same run. Default Windows pins that were not in the backup stay unless `-ExactQuickAccess` is passed; Verify lists them as `Extra`.
- Notepad++ unsaved tabs exist only while "Remember current session" and "Enable session snapshot and periodic backup" (Preferences > Backup) are on; record that in the coverage report. A running instance snapshots every few seconds, so close Notepad++ before the final collect (`RunningAtCollect` says if it was open). `session.xml` stores absolute paths, so a plain folder paste breaks tabs when the user name/profile path changes; the script remaps them. Restore needs Notepad++ closed and refuses otherwise; settings may be placed before installing Notepad++. Tabs that point at saved documents (e.g. `Documents\*.txt`) are not inside the Notepad++ folder: `SavedFileTabs` lists them so the personal-data backup covers them, and they stay Pending until restored. Plugins themselves (DLLs under the install `plugins\`) are reinstalled through Plugins Admin; only their configs are in the payload.
- AppFolders: Zotero is skipped at collect while it runs (copying a live `zotero.sqlite` can corrupt the backup); close it first. Other apps are copied with `RunningAtCollect` recorded. Restore refuses per app while it runs. XYplorer only reads the restored folder when its install `Startup.ini` points there; Restore reports `Pending` until it does. PowerToys also has its own Settings > General > Backup & restore; the folder copy covers the same JSON settings. Verify reports app-rewritten files as Pending ("changed since backup"), missing files as problems.
- DesktopIcons: positions are kept per item name and per monitor/resolution layout. Restore desktop files first, then apply; icons whose files are absent are dropped by Explorer. A different monitor setup can re-flow icons; compare against `desktop.png`.- The raw Quick Access jump list is a fallback: copy it into `%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations` with Explorer stopped only if verb-based pinning is unavailable. It also replaces frequent/recent history.

The payload holds personal templates, app settings (Zotero library database included) and folder paths. App folders can contain tokens or login state (e.g. Zotero sync key in prefs.js); store the payload with the same care as other personal data and never publish it. Keep it in the snapshot as its own `desktop-settings/` folder with a manifest; it is not part of the metadata-only inventory archive.
