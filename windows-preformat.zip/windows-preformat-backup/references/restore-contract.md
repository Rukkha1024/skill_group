# Restore targets, evidence and helper contracts

Use `SchemaVersion: 2` for new derived targets. Never update an original v1 snapshot in place. Input precedence: latest explicit instruction, current-session override, saved user defaults, archived desired target, historical inventory. Inventory entries do not automatically become install targets.

## Minimal target and results

A v2 target contains `SchemaVersion`, `Preferences`, and `Items`. Each item has `Id`, `Kind` (`Application`, `AgentSettings`, `DesktopSettings`, `SmbMapping`, `SshHost`, `Wsl`, `Exclusion`), `Environment`, `Desired`, `RequiredDimensions`, and optional `Source`. IDs are unique. `Preferences` includes `StandaloneWindowsPythonCount: 1`, `ExcludeAnaconda: true`, `ExcludeJupyter: true`, `AgentSettingsPrecedence: preserve-current`, `WorkstationHostCount: 2`, and `CleanupOwnedTemporaryFiles: true` for this user. Only requested environments belong in `Items`.

Results use the same IDs and separate `Installation`, `Settings`, `Authentication`, and `Functional` dimension objects. Each has `Status`, `CheckedAt`, `Evidence` (a short description or a relative evidence file), and optional `Context`. Statuses: `Verified`, `Partial`, `NeedsAuthentication`, `MissingBackup`, `ExcludedByUser`, `Failed`, `NotApplicable`, `NotChecked`. NotApplicable is acceptable only for a dimension not required by the target. ExcludedByUser is successful only on an explicit exclusion. An installation or parse success cannot fill another dimension automatically.

Results also contain `SchemaVersion`, `VerifiedAt`, and `Items`. Evidence must be at least as recent as the latest scope/configuration change (`ChangedAt`, when supplied), no older than 24 hours at handoff, and collected in the relevant environment/logon context. `restore-state.py verify --target ... --results ...` recomputes completion; old reports are historical evidence, not a success override. It is read-only unless an explicit output path is supplied.

`restore-state.py normalize --source ... --overrides ... --output ...` reads the legacy manifest used in this restoration (`Windows.Programs`, `Wsl`, `Smb`, `Ssh`) and user overrides, or an existing v2 target. Unknown legacy structures cause an explicit error instead of an empty complete target. AI settings are added as explicit targets even when old metadata has no settings payload; that condition must lead to MissingBackup until a verified source is found. New output paths must not equal either input. Reports use case-sensitive JSON keys; do not parse case-only SSH aliases with PowerShell 5's case-insensitive JSON conversion.

`DesktopSettings` items use IDs `desktop-startmenu`, `desktop-taskbar`, `desktop-office-templates`, `desktop-quickaccess`, `desktop-notepadplusplus`, `Environment: WindowsDesktop`, `Desired: {Category, Source}` and `RequiredDimensions: [Settings]`; `desktop-settings.ps1 -Mode Verify -ResultPath ...` emits matching Settings observations. A category absent from the backup is MissingBackup; Pending paths/apps keep it Partial.

## Work journal and cleanup

A session work journal contains `SchemaVersion: 2`, `SessionId`, absolute `WorkRoot`, `ProtectedRoots` (original backups, installed programs, live WSL storage, rollback settings and final results), `Artifacts`, `RetainedFiles`, and `RetainedLaunchers`. Create it at session start; register each artifact when creating it, not from a drive-root name glob afterward. Each artifact is an absolute path inside WorkRoot, has `Owned: true`, `Disposable: true`, and a hash for files. A registered disposable directory must have its complete file list and hashes in `Files`. New/unregistered files block deletion of that directory. No secrets or command lines with credentials belong in a journal.

RetainedFiles contains the final absolute path and SHA256. RetainedLaunchers contains a `Path` and explicit dependency `Paths`; keep all dependencies outside disposable paths and update documentation references before applying cleanup. Pass any additional backups/storage to `-ProtectedRoots` as well.

`cleanup-restore.ps1 -Journal <path>` previews validated deletions and does not write/delete anything. `-Apply -ResultPath <final-report-path>` rechecks ownership, file hashes, directory coverage, path ancestry/reparse points, protected roots, retained files/launchers, running executables/services, Appx install paths, WSL base paths and unfinished session tasks before deletion. It never unregisters WSL, empties the recycle bin, or deletes arbitrary user folders. A second run skips already removed entries, preserving the original journal.

## Portable desktop verification

`verify-restore.ps1 -Target <v2-json> [-ResultPath ...] [-CheckSsh]` performs read-only checks in the invoking context. Run it in the actual user's non-elevated desktop session for drive-letter acceptance. It reads saved and current mappings separately, checks UNC plus drive directory enumeration, records Windows identity/elevation/session, discovers Python without executing unknown interpreters, and checks current VS Code profile extension registrations. No credentials are queried. `-CheckSsh` is only for known, reviewed SSH configs; supplied aliases must be explicit single hosts without Match exec/ProxyCommand discovery.

`connect-smb.ps1 -Drive W: -Target \\server\share -UserName account` previews mapping metadata. `-Apply` attempts the existing OS credential first, then a masked local dialog if needed. `-SaveCredentials` persists only credentials entered for that target to Windows Credential Manager; no clear password parameter exists. It preserves a conflicting mapping/physical drive and records no password. Call it from a portable launcher as the desktop user; never enable global linked administrator drive sessions.

`agent-settings.py` has `collect`, `restore`, `verify` subcommands; collect/restore require `--apply` for writes. `verify --probe-mcp` performs only MCP initialize/tool-list handshakes, not model calls or tool execution. See agent-settings.md for the private bundle and path-map interfaces.
