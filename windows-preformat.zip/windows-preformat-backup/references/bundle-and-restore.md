# Bundle and restoration details

## A useful portable layout

Use a new timestamped snapshot beneath the chosen durable destination. Names are examples, not fixed requirements:

For this user's human-facing view, additionally provide a separate Korean-named guide folder with two primary files (first-read instructions and a restoration prompt) and optional detail in a subfolder. Use Korean filenames. Keep the canonical technical inventory intact, and identify actual backup payload paths separately from shortcuts. Include the human view in the metadata archive so it remains available after extraction.

Pair Korean and official English product names in descriptions. Provide a verified vendor/developer download, product, Store or installation-guide URL with a checked date and page type; a guide or homepage is not a direct installer. Use publisher/developer primary sources, distinguish similarly named forks and internal driver labels from product names, and mark unavailable/uncertain links rather than inventing URLs. User-managed exclusions such as Hancom belong outside the active install target while their historical records remain intact.

## Program lists and responsibility

Derive readable lists and the machine restore target from the same reviewed catalog. Separate `Codex installation`, `user installation/action`, and `excluded or historical only`. A GUI is not proof of manual-only installation: check available package-manager IDs and vendor installation methods. When manual action is genuinely needed, state why and whether Codex can complete other steps first. Keep user-managed Hancom outside the ordinary requested program list and active target, without deleting original inventory records.

Each human-facing entry should contain `Korean name (official English name)`, observed version or unknown, install responsibility, official URL, page type, verification date/status, and a short action/reason. For example, the display name can be `반디집 (Bandizip)`; determine the actual version, installation method and URL from current evidence rather than copying example data. Retain original registration names, IDs and evidence in JSON/CSV. Research URLs anew when preparing or updating the catalog; checking an archived list for integrity is not itself a fresh website verification. Clearly flag unavailable or unverified links.

Put the user-install list in the Korean guide folder, such as `세부_목록과설정/사용자_직접설치_프로그램목록.txt`, and show the full reinstall list separately when useful. The first-read guide must point directly to it. Before handoff, check that neither list contradicts the active target, excluded apps are not resurrected by bulk imports, and the copy/paste prompt specifies fresh minimal WSL versus full recovery accurately.

## Archive layout and verification

```text
snapshot/
  inventory/                  Metadata, Korean app list, target, instructions, status
    windows-programs.json
    windows-store-apps.json
    network-drives-saved.json
    wsl/<distro>/
    RESTORE-TARGET.json
    RESTORE-PROMPT.txt
    START-HERE.txt
    SHA256SUMS.csv
    Verify-Manifest.ps1
  inventory.zip               Archive only inventory, no private SSH payload
  wsl-private/                Protected/encrypted before creating sensitive exports
    wsl-<distro>.tar           Optional original filesystem export
  desktop-settings/           Start/taskbar/Office/Quick Access/Notepad++/app folders/desktop icons (scripts/desktop-settings.ps1)
    desktop-settings.json
    SHA256SUMS.csv
  ssh-private/                Restricted before writing private keys
    payload/
    ssh.zip
  artifacts.sha256.csv        Relative hashes for inventory.zip/tar/private SSH ZIP
  skill.zip                   Clean reusable skill, no live data/keys
```

Inventory and artifact manifests use `RelativePath,Bytes,SHA256`. All paths must remain beneath the supplied verification root. Use the inventory root for its manifest and snapshot root for external artifacts; do not insert `..` paths into an inventory manifest. `scripts/verify-manifest.ps1` performs verification only; it does not regenerate expected hashes, execute programs or unlock private backups. If access is denied, report it instead of calling the item verified.

Include the inspection date, source profile/OS and paths, desired scope, collection errors, backed-up content versus metadata-only entries, and verification limits. Use UTF-8 explicitly with PowerShell 5.1; use UTF-8 BOM for CSV intended to open in Excel. Windows WSL informational commands redirect UTF-16LE; Linux command stdout is usually UTF-8. Do not repair lossy UTF-16 by merely stripping NUL characters.

## Non-obvious Windows inventory issues

- Inspect machine 64-bit/32-bit/current-user uninstall keys, current-user Appx/Store packages, Start menu, actual executable directories, global package managers and CLI resolution (`Get-Command -All`). Do not use `Win32_Product`, which can trigger MSI repair.
- A component registration or stale uninstall row is not proof of the executable version currently used. A native CLI on PATH may be newer than a winget registration. Preserve both observations and their evidence.
- Raw winget exports can omit installed Chrome/Firefox or other products. Cross-check full inventories and create a manual-install section. Package ID must be verified independently of its friendly label.
- `Canonical.Ubuntu` identifies an app package, not a Linux release. Select the actual required distro identifier from `wsl --list --online` and verify `/etc/os-release`; preserve the requested registration name for `\\wsl.localhost\<name>` mappings.
- Product names may contain a meaningful release number even when MSI `DisplayVersion` is generic. Keep both, and do not invent executable-version evidence. A driver/SDK component version may differ from the parent installer version.
- Optional Store/system frameworks are often already present after reinstall. Conditional dependencies are not a blanket command to reinstall every inventory row. Restore actual apps/workloads and required compatibility runtimes.
- Record Visual Studio instance/selected workload/component IDs when applicable. SDK/component setup versions are not necessarily SDK or compiler versions.

## Developer environments

Capture Windows and Linux environments separately. Preserve per-interpreter Python package lists rather than assuming `python` or `pip` points at every installation. Record npm global package versions, executable resolution and VS Code extension IDs/versions without invoking every agent.

For Conda, export history/full YAML and explicit package URLs where useful. Full YAML includes pip dependencies; explicit URLs alone do not. Restore pip sections too. Deduplicate case-only Windows environment paths. An existing `base` needs appropriate updating, not an attempt to create a second `base`. Adapt old `prefix` to the new profile without changing the original evidence. Windows builds and Linux builds cannot be mixed.

Playwright/browser automation packages can need separately downloaded browser runtimes. Inspect the current cache and the Python/package version independently of the internal driver build label. Preserve relevant browser families/revisions and validate launches after restoration; do not add this Windows-only environment to a minimal WSL target.

## SMB and restoration

Separate disconnected saved mappings from active mappings/sessions. Z:/another mapped letter can appear saved yet be inaccessible in the current logon context while the direct WSL UNC works. Verify actual file access after remapping. Remote TCP port reachability is not successful SMB authentication. Keep account names and dependencies; request passwords interactively only when needed, not through logs/files.

Restore measured client compatibility settings and applicable network/firewall scopes. Do not open sharing on all networks or create Windows-generated administrative shares by hand. Match current share paths/accounts and update references for changed letters/SIDs. Tailscale authentication/device addresses may change; do not force an old local overlay IP.

## Restoration prompt and handoff

The prompt should identify the desired Windows/WSL targets, source precedence, immutable backup paths, sensible handling of unavailable versions, credential/license tasks, SSH ownership/permissions, and functional acceptance checks. Existing data/keys/distro registrations are not disposable merely because they conflict with a target name. Do independent installation work while awaiting a credential or license for a particular item.

Report results per app/mapping/environment, including actual installed versions, substitutions, failures and user-input needs. Review failures must not be erased by regenerating hashes first. Regenerate manifests/ZIPs only after authorized derived-output changes, preserving original snapshots.

Start menu, taskbar, Office template, Quick Access, Notepad++, registered app folder and desktop icon settings are in scope only through the `desktop-settings/` payload and its Verify result; see desktop-settings.md. Keep Windows desktop/documents/downloads, browser personal data, local research/notes, app settings and license records outside the claimed backup scope unless actually copied and verified. WSL export excludes Windows-mounted data. Passphrases and Windows credential/agent stores are not recovered just by copying metadata.

## Desktop SMB and reboot acceptance

Validate mappings in the non-elevated desktop user's session; record SID, session and elevation separately from installer/admin observations. Do not enable global linked sessions to hide missing administrator drive letters. An authorized Interactive Limited one-shot task can perform desktop checks; remove it after completion. Never put secrets into task arguments/scripts/transcripts. An already-provided credential may travel through a current-SID-only local pipe, or use a masked local dialog for an unresolved target.

Resolve actual iMac share/account metadata from the target or an authorized known SSH connection. A hostname/port is not a share name or authentication success. `connect-smb.ps1` uses native WNetAddConnection2 for compatibility; keep parameter/transport failures separate from rejected credentials. Only try a supplied candidate for its explicit account/endpoint; stop after rejection. Persistent mapping and saved credential are independent observations.

A user restart report is not proof of successful continuation. Recheck current installs, exclusions, preferences and outstanding work before resuming. Verify PowerToys settings UI and required CLI/SDK behavior; investigate actual compatibility evidence before choosing an OS update. Never hardcode this session's KB or replace a functioning user-installed Office edition.

For one standalone Windows Python, compare registered interpreters, known installation paths, PATH and launcher entries; run SSL/venv/pip checks only on the selected known executable. Preserve system/app runtimes, necessary venvs and notebooks. Apply Anaconda/Jupyter exclusions to all package exports, extension profiles/packs and continuation steps. Add excluded IDs to `settingsSync.ignoredExtensions`, preserving other sync preferences; check after sync/restart. Do not infer reappearance's cause from an extension list alone. Five Jupyter extensions reappeared after the October 2026 success report: fresh observations override that report.

## Owned work and completion cleanup

Use one session-owned work root and the restore-contract.md journal, including hashes/ownership registered when artifacts are created. Large downloads may use a deliberately chosen working directory separate from original backups and installed applications. Do not scatter root-level scripts/screenshots or duplicate installers.

Relocate the final Korean report, minimum evidence and portable reconnect tools before cleanup. Preserve original backups, rollback settings, keys and personal files. Launchers use relative paths; UTF-8 batch launchers with Korean paths start with an ASCII `chcp 65001` line before non-ASCII commands. PowerShell 5 scripts containing Korean use UTF-8 BOM.

Preview and inspect cleanup-restore.ps1's exact registered paths, then apply within the authorized scope. It rejects unregistered/modified files, links/escaping paths, protected roots, process/service/WSL/Appx/task dependencies and broken retained launchers. Update live human-facing references to removed logs/scripts before handoff. Report deleted files/bytes and retained location. Cleanup cannot turn unresolved authentication/licenses/missing settings into success.
