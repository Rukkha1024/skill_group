#!/usr/bin/env python3
"""Normalize derived restore targets and verify fresh per-dimension evidence."""
import argparse
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import re
import sys

DIMENSIONS = {'Installation', 'Settings', 'Authentication', 'Functional'}
STATUSES = {'Verified', 'Partial', 'NeedsAuthentication', 'MissingBackup', 'ExcludedByUser', 'Failed', 'NotApplicable', 'NotChecked'}
DEFAULTS = {'StandaloneWindowsPythonCount': 1, 'ExcludeAnaconda': True, 'ExcludeJupyter': True,
            'AgentSettingsPrecedence': 'preserve-current', 'WorkstationHostCount': 2, 'CleanupOwnedTemporaryFiles': True}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def normalized(source, overrides=None):
    overrides = overrides or {}
    latest = dict(overrides.get('Preferences', {}))
    for old, new in [('DesiredStandaloneWindowsPythonCount', 'StandaloneWindowsPythonCount'), ('RemoveAnaconda', 'ExcludeAnaconda'),
                     ('RemoveJupyter', 'ExcludeJupyter'), ('WorkstationSSHHostCount', 'WorkstationHostCount')]:
        if old in overrides:
            latest[new] = overrides[old]
    if source.get('SchemaVersion') == 2 and isinstance(source.get('Items'), list):
        target = json.loads(json.dumps(source))
        target['Preferences'] = {**DEFAULTS, **source.get('Preferences', {}), **latest}
        prefs = target['Preferences']
        apps = [i for i in target['Items'] if i.get('Kind') == 'Application' and i.get('Environment') in {'Windows', 'WindowsDesktop'}]
        pythons = [i for i in apps if re.fullmatch(r'Python \d+\.\d+', i.get('Desired', {}).get('Name', ''))]
        selected = max(pythons, key=lambda i: tuple(map(int, re.findall(r'\d+', i['Desired']['Name'])))) if pythons else None
        for item in apps:
            desired = item.get('Desired', {})
            name = desired.get('Name', '')
            if ((prefs['ExcludeAnaconda'] and re.search('anaconda|conda', name, re.I)) or
                (prefs['ExcludeJupyter'] and re.search('jupyter', name, re.I)) or
                (prefs['StandaloneWindowsPythonCount'] == 1 and item in pythons and item is not selected)):
                item['Kind'], item['RequiredDimensions'], desired['Action'] = 'Exclusion', ['Functional'], 'Exclude'
        if prefs['ExcludeJupyter'] and not any(i['Id'] == 'exclude-jupyter' for i in target['Items']):
            target['Items'].append({'Id': 'exclude-jupyter', 'Kind': 'Exclusion', 'Environment': 'Windows',
                'Desired': {'Name': 'Jupyter packages and local VS Code extensions', 'Action': 'Exclude'}, 'RequiredDimensions': ['Functional']})
        if overrides:
            target['ChangedAt'] = overrides.get('ChangedAt', datetime.now(timezone.utc).isoformat())
        validate_target(target)
        return target
    if not isinstance(source.get('Windows', {}).get('Programs'), list):
        raise ValueError('Unknown legacy target structure')
    prefs = {**DEFAULTS, **latest}
    items = []
    def add(identifier, kind, env, desired, required, origin=None):
        item = {'Id': identifier, 'Kind': kind, 'Environment': env, 'Desired': desired, 'RequiredDimensions': required}
        if origin is not None:
            item['Source'] = origin
        items.append(item)
    programs = source['Windows']['Programs']
    pythons = [p for p in programs if re.fullmatch(r'Python \d+\.\d+', p.get('EnglishName', ''))]
    selected = max(pythons, key=lambda p: tuple(map(int, re.findall(r'\d+', p['EnglishName'])))) if pythons else None
    managed = {p.get('EnglishName', p.get('Name')) for p in source.get('UserManagedPrograms', []) if isinstance(p, dict)}
    for index, p in enumerate(programs):
        name = p.get('EnglishName') or p.get('OriginalName') or 'Unknown application'
        excluded = ((prefs['ExcludeAnaconda'] and re.search('anaconda|conda', name, re.I)) or
                    (prefs['ExcludeJupyter'] and re.search('jupyter', name, re.I)) or
                    (prefs['StandaloneWindowsPythonCount'] == 1 and p in pythons and p is not selected))
        add('windows-app-'+str(index), 'Exclusion' if excluded else 'Application', 'Windows',
            {'Name': name, 'PackageIdentifier': p.get('PackageIdentifier'), 'Version': p.get('PreferredApplicationVersion'),
             'Action': 'Exclude' if excluded else 'PreserveUserInstalled' if name in managed or 'Office' in name or '365' in name else 'InstallIfMissing'},
            ['Functional'] if excluded else ['Installation'], p)
    for agent in ['codex', 'claude']:
        add('settings-windows-'+agent, 'AgentSettings', 'Windows', {'Agent': agent, 'Precedence': prefs['AgentSettingsPrecedence']},
            ['Settings', 'Authentication', 'Functional'], {'Availability': 'NotRecordedInLegacyMetadata'})
    wsl = source.get('Wsl', source.get('WSL', {}))
    if wsl:
        add('wsl-environment', 'Wsl', 'WSL', {'Mode': 'FreshMinimal', 'Agents': ['codex', 'claude']}, ['Installation', 'Functional'], wsl)
        for agent in ['codex', 'claude']:
            add('settings-wsl-'+agent, 'AgentSettings', 'WSL', {'Agent': agent, 'Precedence': prefs['AgentSettingsPrecedence']},
                ['Settings', 'Authentication', 'Functional'], {'Availability': 'VerifySelectedFilesInExport'})
    smb = source.get('Smb', {})
    if isinstance(smb, dict) and smb and not any(k in smb for k in ['Mappings', 'SavedMappings', 'Drives']):
        raise ValueError('Legacy SMB structure needs explicit mapping')
    mappings = smb if isinstance(smb, list) else smb.get('Mappings', smb.get('SavedMappings', smb.get('Drives', [])))
    if smb and not isinstance(mappings, list):
        raise ValueError('Legacy SMB structure needs explicit mapping')
    for i, mapping in enumerate(mappings):
        add('smb-'+str(i), 'SmbMapping', 'WindowsDesktop', mapping, ['Settings', 'Authentication', 'Functional'])
    if overrides.get('AdditionalIMacSMB'):
        add('smb-imac', 'SmbMapping', 'WindowsDesktop', overrides['AdditionalIMacSMB'], ['Settings', 'Authentication', 'Functional'])
    ssh = source.get('Ssh', {})
    if ssh:
        for platform, alias in [('Windows', overrides.get('WindowsSSHHost', 'cho-workstation')),
                                ('WSL', overrides.get('WslSSHHost', 'cho-workstation-wsl'))]:
            add('ssh-workstation-'+platform.lower(), 'SshHost', 'WindowsDesktop', {'Alias': alias, 'ExpectedPlatform': platform,
                'Address': overrides.get('WindowsSSHAddress') if platform == 'Windows' else overrides.get('WslSSHAddress')},
                ['Settings', 'Authentication', 'Functional'], ssh)
    desktop = source.get('DesktopSettings', {})
    if desktop:
        for category in desktop.get('Categories', ['StartMenu', 'Taskbar', 'OfficeTemplates', 'QuickAccess', 'NotepadPlusPlus', 'AppFolders', 'DesktopIcons']):
            identifier = {'OfficeTemplates': 'desktop-office-templates'}.get(category, 'desktop-' + category.lower())
            add(identifier, 'DesktopSettings', 'WindowsDesktop', {'Category': category, 'Source': desktop.get('Source')}, ['Settings'])
    if prefs['ExcludeJupyter']:
        add('exclude-jupyter', 'Exclusion', 'Windows', {'Name': 'Jupyter packages and local VS Code extensions', 'Action': 'Exclude'}, ['Functional'])
    if overrides.get('ChangedAt'):
        changed = overrides['ChangedAt']
    else:
        changed = datetime.now(timezone.utc).isoformat()
    target = {'SchemaVersion': 2, 'ChangedAt': changed, 'Preferences': prefs, 'Items': items, 'LegacySourceReadOnly': True}
    validate_target(target)
    return target


def validate_target(target):
    if target.get('SchemaVersion') != 2 or not isinstance(target.get('Items'), list) or not target['Items']:
        raise ValueError('Nonempty v2 target required')
    seen = set()
    for item in target['Items']:
        if not item.get('Id') or item['Id'] in seen:
            raise ValueError('Missing or duplicate target ID')
        seen.add(item['Id'])
        if item.get('Kind') not in {'Application', 'AgentSettings', 'DesktopSettings', 'SmbMapping', 'SshHost', 'Wsl', 'Exclusion'}:
            raise ValueError('Unknown target kind')
        dims = item.get('RequiredDimensions', [])
        if not dims or any(d not in DIMENSIONS for d in dims) or len(dims) != len(set(dims)):
            raise ValueError('Invalid required dimensions')


def date(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('Evidence timestamp needs a timezone')
    return result.astimezone(timezone.utc)


def verify(target, results, now=None):
    validate_target(target)
    if results.get('SchemaVersion') != 2:
        raise ValueError('v2 per-dimension results required; legacy success is insufficient')
    now = now or datetime.now(timezone.utc)
    boundary = date(target['ChangedAt']) if target.get('ChangedAt') else datetime.min.replace(tzinfo=timezone.utc)
    indexed = {}
    for item in results.get('Items', []):
        if not item.get('Id') or item['Id'] in indexed:
            raise ValueError('Missing or duplicate result ID')
        indexed[item['Id']] = item
    checks = []
    for item in target['Items']:
        result = indexed.get(item['Id'], {})
        for dimension in item['RequiredDimensions']:
            data = result.get(dimension, {})
            status = data.get('Status', 'NotChecked')
            issue = None
            if status not in STATUSES:
                issue = 'InvalidStatus'
            elif status != 'Verified' and not (item['Kind'] == 'Exclusion' and status == 'ExcludedByUser'):
                issue = status
            if issue is None:
                try:
                    checked = date(data['CheckedAt'])
                    if checked < boundary or now-checked > timedelta(hours=24) or checked > now+timedelta(minutes=5):
                        issue = 'StaleEvidence'
                    elif not data.get('Evidence'):
                        issue = 'EvidenceMissing'
                    elif item['Environment'] == 'WindowsDesktop' and not data.get('Context'):
                        issue = 'DesktopContextMissing'
                except (KeyError, ValueError, TypeError):
                    issue = 'TimestampMissingOrInvalid'
            checks.append({'Id': item['Id'], 'Dimension': dimension, 'Status': status, 'Accepted': issue is None, 'Issue': issue})
    return {'SchemaVersion': 2, 'VerifiedAt': now.isoformat(), 'Complete': all(c['Accepted'] for c in checks), 'Checks': checks}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    normal = sub.add_parser('normalize')
    normal.add_argument('--source', required=True)
    normal.add_argument('--overrides')
    normal.add_argument('--output')
    check = sub.add_parser('verify')
    check.add_argument('--target', required=True)
    check.add_argument('--results', required=True)
    check.add_argument('--output')
    args = p.parse_args(argv)
    try:
        result = normalized(read(args.source), read(args.overrides) if args.overrides else None) if args.command == 'normalize' else verify(read(args.target), read(args.results))
        if args.output:
            output = Path(args.output).resolve()
            inputs = [args.source, args.overrides] if args.command == 'normalize' else [args.target, args.results]
            if any(output == Path(i).resolve() for i in inputs if i):
                raise ValueError('Never overwrite source targets/results')
            with output.open('x', encoding='utf8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
        print(json.dumps(result, ensure_ascii=True, indent=2))
        return 0 if args.command == 'normalize' or result['Complete'] else 2
    except (ValueError, KeyError, OSError) as e:
        print(json.dumps({'Status': 'Failed', 'ErrorType': type(e).__name__}))
        return 1


if __name__ == '__main__':
    sys.exit(main())
