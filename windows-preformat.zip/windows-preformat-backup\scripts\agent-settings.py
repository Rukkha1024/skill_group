#!/usr/bin/env python3
"""Private selected settings collection/restoration. Python 3.11+; preview first."""
import argparse
import copy
import csv
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import queue
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
import tomllib
import urllib.error
import urllib.request
from datetime import datetime, timezone

AUTH_NAMES = {'auth.json', '.credentials.json', 'credentials.json', 'history.jsonl'}
STATE_KEYS = {'mcpServers', 'theme', 'showSpinnerTree'}
SELECTION_KEYS = ('model', 'model_reasoning_effort', 'plan_mode_reasoning_effort', 'service_tier')
EXCLUDED_DIRS = {'.git', 'node_modules', '__pycache__', '.system'}


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def no_links(path):
    p = Path(path).absolute()
    for node in [p, *p.parents]:
        if node.exists() and (node.is_symlink() or getattr(node, 'is_junction', lambda: False)()):
            raise ValueError('Linked destination is outside automatic write scope')
        if node.exists() and os.name == 'nt' and node.stat().st_file_attributes & 0x400:
            raise ValueError('Reparse destination is outside automatic write scope')
    return p


def private_directory(path):
    p = no_links(path)
    if p.exists():
        raise ValueError('Use a new private output/rollback directory')
    p.mkdir(parents=True, mode=0o700)
    if os.name == 'nt':
        flags = ctypes.c_ulong()
        volume = ctypes.create_unicode_buffer(260)
        if not ctypes.windll.kernel32.GetVolumePathNameW(str(p), volume, 260):
            raise ValueError('Cannot identify private filesystem')
        if not ctypes.windll.kernel32.GetVolumeInformationW(volume.value, None, 0, None, None, ctypes.byref(flags), None, 0) or not flags.value & 8:
            raise ValueError('Private destination requires persistent ACLs')
        rows = csv.reader(io.StringIO(subprocess.check_output(['whoami.exe', '/user', '/fo', 'csv', '/nh'], text=True)))
        sid = next(rows)[1]
        if not re.fullmatch(r'S-1-\d+(?:-\d+)+', sid):
            raise ValueError('Cannot resolve current SID')
        subprocess.run(['icacls.exe', str(p), '/inheritance:r', '/grant:r',
                        '*'+sid+':(OI)(CI)F', '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F'],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        p.chmod(0o700)
    return p


def atomic_write(path, data):
    p = no_links(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.preformat-' + os.urandom(5).hex())
    try:
        with tmp.open('xb') as f:
            if os.name != 'nt':
                os.fchmod(f.fileno(), 0o600)
            f.write(data)
        if os.name == 'nt':
            rows = csv.reader(io.StringIO(subprocess.check_output(['whoami.exe', '/user', '/fo', 'csv', '/nh'], text=True)))
            sid = next(rows)[1]
            subprocess.run(['icacls.exe', str(tmp), '/inheritance:r', '/grant:r', '*'+sid+':F', '*S-1-5-18:F', '*S-1-5-32-544:F'],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        os.replace(tmp, p)
    finally:
        if tmp.exists():
            tmp.unlink()


def emit(result, report=None):
    text = json.dumps(result, ensure_ascii=True, indent=2)
    if report:
        if Path(report).exists():
            raise ValueError('Use a new nonsecret report output')
        atomic_write(report, (text+'\n').encode('utf8'))
    print(text)


def structured(path, data):
    if path.suffix.lower() == '.toml':
        return tomllib.loads(data.decode('utf-8-sig'))
    if path.suffix.lower() == '.json':
        return json.loads(data.decode('utf-8-sig'))
    return None


def command_files(command):
    # Parse only literal file tokens. Never evaluate shell syntax or expose commands.
    if not isinstance(command, str):
        return []
    try:
        tokens = shlex.split(command, posix=not bool(re.search(r'[A-Za-z]:[\\/]', command)))
    except ValueError:
        return []
    return [t.strip('\"\'') for t in tokens if re.search(r'\.(?:py|ps1|sh|js|mjs|cjs)$', t.strip('\"\''), re.I)]


def references(obj, trail=()):
    out = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in {'config_file', 'model_instructions_file', 'instructions_file'} and isinstance(value, str):
                out.append(value)
            if key in {'command', 'command_windows', 'commandWindows'} and 'hooks' in trail:
                out.extend(command_files(value))
            if trail and trail[0] == 'marketplaces' and key == 'source' and isinstance(value, str) and (value.startswith(('/', '~', '.')) or re.match(r'^[A-Za-z]:', value)):
                out.append(value)
            out.extend(references(value, trail+(key,)))
    elif isinstance(obj, list):
        for item in obj:
            out.extend(references(item, trail))
    return out


def resolve_reference(value, parent, home, codex):
    replacements = {'${HOME}': str(home), '$HOME': str(home), '${CODEX_HOME}': str(codex), '$CODEX_HOME': str(codex)}
    for key, val in replacements.items():
        value = value.replace(key, val)
    if value.startswith('~/') or value.startswith('~\\'):
        return home/value[2:]
    p = Path(value)
    return p if p.is_absolute() else parent/p


def discover(home, codex, additional=(), allowed=()):
    home, codex = Path(home).absolute(), Path(codex).absolute()
    roots = [home.resolve(), codex.resolve(), *(Path(p).resolve() for p in allowed)]
    explicit_roots = [Path(p).resolve() for p in allowed]
    seeds = [codex/'config.toml', codex/'hooks.json', codex/'AGENTS.md', home/'.claude/settings.json',
             home/'.claude/settings.local.json', home/'.claude/hooks.json', home/'.claude/CLAUDE.md', home/'.claude.json']
    pending = [(p, False, None) for p in seeds] + [(Path(p).absolute(), True, None) for p in additional]
    for root in [codex/'skills', *(home/'.claude'/n for n in ['agents', 'commands', 'skills', 'hooks'])]:
        if root.exists():
            pending.append((root, True, None))
    files, gaps, seen = [], [], set()
    while pending:
        p, required, referrer = pending.pop(0)
        canonical = p.resolve()
        identity = (str(p.absolute()), str(canonical))
        if identity in seen:
            continue
        seen.add(identity)
        if p.name.casefold() in AUTH_NAMES:
            continue
        linked = p.is_symlink() or getattr(p, 'is_junction', lambda: False)()
        if linked and not any(canonical.is_relative_to(root) for root in explicit_roots):
            gaps.append({'Path': str(p), 'Referrer': referrer, 'Reason': 'LinkedSourceRequiresExplicitScope'})
            continue
        if not any(canonical.is_relative_to(root) for root in roots):
            gaps.append({'Path': str(p), 'Referrer': referrer, 'Reason': 'ExternalSourceNotAuthorized'})
            continue
        if not p.exists():
            if required:
                gaps.append({'Path': str(p), 'Referrer': referrer, 'Reason': 'MissingReferencedFile'})
            continue
        if p.is_dir():
            for child in sorted(p.iterdir()):
                if child.name not in EXCLUDED_DIRS:
                    pending.append((child, True, str(p)))
            continue
        if not p.is_file():
            gaps.append({'Path': str(p), 'Reason': 'NotARegularFile'})
            continue
        data = p.read_bytes()
        if len(data) > 50*1024*1024:
            gaps.append({'Path': str(p), 'Reason': 'OversizedDependencyRequiresExplicitRecovery'})
            continue
        kind = 'bytes'
        try:
            obj = structured(p, data)
            if p == home/'.claude.json':
                obj = {k: v for k, v in obj.items() if k in STATE_KEYS}
                data = (json.dumps(obj, ensure_ascii=False, indent=2)+'\n').encode('utf8')
                kind = 'claude-state'
            if obj is not None:
                for ref in references(obj):
                    pending.append((resolve_reference(ref, p.parent, home, codex), True, str(p)))
                if p == codex/'config.toml':
                    for plugin_id, value in obj.get('plugins', {}).items():
                        if isinstance(value, dict) and value.get('enabled') and '@' in plugin_id:
                            plugin, market = plugin_id.split('@', 1)
                            if all(re.fullmatch(r'[A-Za-z0-9_.-]+', part) and part not in {'.', '..'} for part in [plugin, market]):
                                pending.append((codex/'plugins/cache'/market/plugin, True, str(p)))
                            else:
                                gaps.append({'Path': str(p), 'Reason': 'InvalidPluginIdentifier'})
        except (ValueError, TypeError, UnicodeError):
            gaps.append({'Path': str(p), 'Reason': 'ConfigurationParseFailed'})
        if p.is_relative_to(codex):
            area, relative = 'codex', p.relative_to(codex).as_posix()
        elif p.is_relative_to(home):
            area, relative = 'home', p.relative_to(home).as_posix()
        else:
            area, relative = 'external', str(p)
        files.append({'Source': str(p), 'Area': area, 'RelativePath': relative, 'Kind': kind,
                      'Bytes': len(data), 'SHA256': sha(data), '_data': data})
    return files, gaps


def collect(args):
    home = Path(args.home).absolute()
    codex = Path(args.codex_home).absolute() if args.codex_home else home/'.codex'
    files, gaps = discover(home, codex, args.additional_config, args.allow_source_root)
    manifest = {'SchemaVersion': 2, 'Platform': args.platform, 'SourceHome': str(home), 'SourceCodexHome': str(codex),
                'CapturedAt': timestamp(), 'Files': [], 'Gaps': gaps}
    out = private_directory(args.private_output) if args.apply else None
    for i, item in enumerate(files):
        data = item.pop('_data')
        item['Payload'] = 'files/'+str(i).zfill(5)
        manifest['Files'].append(item)
        if out:
            atomic_write(out/item['Payload'], data)
    if out:
        atomic_write(out/'manifest.json', (json.dumps(manifest, indent=2)+'\n').encode('utf8'))
    summary = {'Operation': 'collect', 'Applied': bool(out), 'Status': 'Partial' if gaps or not files else 'Verified',
               'FileCount': len(files), 'Files': [{k: v for k, v in f.items() if k != 'Payload'} for f in manifest['Files']], 'Gaps': gaps}
    emit(summary, args.report if args.apply else None)


def verified_bundle(source):
    root = no_links(source).resolve()
    manifest = load_json(root/'manifest.json')
    if manifest.get('SchemaVersion') != 2:
        raise ValueError('Unsupported settings bundle')
    files = []
    destinations = set()
    for item in manifest['Files']:
        p = no_links(root/item['Payload']).resolve()
        if not p.is_relative_to(root):
            raise ValueError('Settings payload escapes bundle')
        data = p.read_bytes()
        if len(data) != item['Bytes'] or sha(data) != item['SHA256']:
            raise ValueError('Settings payload checksum mismatch')
        rel = item['RelativePath']
        identity = (item['Area'], rel)
        if identity in destinations:
            raise ValueError('Duplicate settings destination')
        destinations.add(identity)
        if item['Area'] != 'external' and (Path(rel).is_absolute() or '..' in Path(rel).parts or re.match(r'^[A-Za-z]:', rel)):
            raise ValueError('Settings destination escapes home')
        if Path(rel).name.casefold() in AUTH_NAMES:
            raise ValueError('Authentication/history payload is excluded')
        files.append((item, data))
    return manifest, files


def path_maps(values):
    result = []
    for value in values:
        old, sep, new = value.partition('=')
        if not sep or not old or not new:
            raise ValueError('Use --path-map old-prefix=new-prefix')
        result.append((old.replace('\\', '/').rstrip('/'), new.replace('\\', '/').rstrip('/')))
    return sorted(result, key=lambda pair: len(pair[0]), reverse=True)


def translate(value, mappings):
    if not isinstance(value, str):
        return value
    normalized = value.replace('\\', '/')
    for old, new in mappings:
        if normalized == old or normalized.startswith(old+'/'):
            return new+normalized[len(old):]
    return value


def map_object(obj, mappings):
    if isinstance(obj, dict):
        return {translate(k, mappings): map_object(v, mappings) for k, v in obj.items()}
    if isinstance(obj, list):
        return [map_object(v, mappings) for v in obj]
    return translate(obj, mappings)


def restore(args):
    manifest, files = verified_bundle(args.source)
    home = no_links(args.home)
    codex = no_links(args.codex_home) if args.codex_home else home/'.codex'
    if args.dependency_directory:
        sys.path.insert(0, args.dependency_directory)
    try:
        import tomlkit
    except ImportError:
        raise ValueError('Restore needs tomlkit in an existing isolated helper environment') from None
    mappings = path_maps(args.path_map)
    mappings += [(str(manifest['SourceCodexHome']).replace('\\', '/'), str(codex).replace('\\', '/')),
                 (str(manifest['SourceHome']).replace('\\', '/'), str(home).replace('\\', '/'))]
    mappings.sort(key=lambda pair: len(pair[0]), reverse=True)
    gaps = copy.deepcopy(manifest.get('Gaps', []))
    outputs, changes, planned_paths = [], [], set()
    for item, data in files:
        rel = item['RelativePath']
        if item['Area'] in {'codex', 'home'}:
            root = codex if item['Area'] == 'codex' else home
            dst = no_links(root/rel)
            if not dst.is_relative_to(root):
                raise ValueError('Destination escapes selected root')
        elif item['Area'] == 'external':
            mapped = translate(rel, path_maps(args.path_map))
            if mapped == rel:
                gaps.append({'Path': rel, 'Reason': 'ExternalDestinationNeedsPathMap'})
                continue
            dst = no_links(mapped)
        else:
            raise ValueError('Unknown settings area')
        if dst.name.casefold() in AUTH_NAMES:
            raise ValueError('Path mapping must not target authentication/history stores')
        if item['Kind'] == 'claude-state' and dst != home/'.claude.json':
            raise ValueError('Claude state must restore only to the selected profile state file')
        if dst in planned_paths:
            raise ValueError('Conflicting translated destinations')
        planned_paths.add(dst)
        previous_data = dst.read_bytes() if dst.exists() else None
        if item['Kind'] == 'claude-state':
            state = json.loads(previous_data.decode('utf-8-sig')) if previous_data is not None else {}
            recovered = map_object(json.loads(data.decode('utf8')), mappings)
            for key in STATE_KEYS:
                if key in recovered:
                    if key == 'mcpServers':
                        state.setdefault(key, {}).update(recovered[key])
                    else:
                        state[key] = recovered[key]
            data = (json.dumps(state, ensure_ascii=False, indent=2)+'\n').encode('utf8')
        elif dst.suffix.lower() in {'.toml', '.json'}:
            obj = map_object(structured(dst, data), mappings)
            if dst == codex/'config.toml':
                current = structured(dst, previous_data) if previous_data is not None else {}
                if args.precedence == 'preserve-current':
                    for key in SELECTION_KEYS:
                        if key in current:
                            obj[key] = current[key]
                    if current.get('model') and current.get('model') != structured(dst, data).get('model'):
                        for key in ['model_context_window', 'model_auto_compact_token_limit']:
                            obj.pop(key, None)
                        changes.append('Archived model limits removed for current model')
                if 'windows' in current and args.platform == 'windows':
                    obj['windows'] = current['windows']
                if 'hooks' in obj and isinstance(obj['hooks'], dict):
                    obj['hooks'].pop('state', None)
                for role, layer in obj.get('agents', {}).items():
                    if isinstance(layer, dict) and layer.get('config_file'):
                        dest_role = resolve_reference(layer['config_file'], codex, home, codex)
                        available = dest_role.exists() or any(translate(f['Source'], mappings).replace('\\', '/') == str(dest_role).replace('\\', '/') for f, _ in files)
                        if not available:
                            layer.pop('config_file')
                            gaps.append({'Path': str(dest_role), 'Reason': 'MissingRoleLayer', 'Role': role})
                # Merge current local plugin/marketplace settings, preserving unrelated installations.
                for key in ['plugins', 'marketplaces']:
                    obj.setdefault(key, {}).update(current.get(key, {}))
            # Disable events whose referenced hook scripts were missing from the collection.
            if isinstance(obj, dict) and isinstance(obj.get('hooks'), dict):
                missing = {translate(g['Path'], mappings).replace('\\', '/') for g in gaps if 'Path' in g}
                for event, groups in list(obj['hooks'].items()):
                    if isinstance(groups, list) and any(str(resolve_reference(ref, dst.parent, home, codex)).replace('\\', '/') in missing for ref in references({'hooks': {event: groups}})):
                        obj['hooks'].pop(event)
                        changes.append('Hook event disabled because a referenced script is missing: '+event)
            data = (tomlkit.dumps(obj) if dst.suffix.lower() == '.toml' else json.dumps(obj, ensure_ascii=False, indent=2)+'\n').encode('utf8')
            structured(dst, data)
        outputs.append((dst, data, sha(previous_data) if previous_data is not None else None))
    rollback = None
    written = []
    for dst, data, previous_hash in outputs:
        if (sha(dst.read_bytes()) if dst.exists() else None) != previous_hash:
            raise ValueError('Active settings changed; preview again instead of overwriting')
        if dst.exists() and dst.read_bytes() == data:
            continue
        if args.apply:
            if rollback is None:
                rollback = private_directory(home/'.windows-preformat-backups'/('settings-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+os.urandom(3).hex()))
            index = len(written)
            if dst.exists():
                atomic_write(rollback/(str(index)+'.before'), dst.read_bytes())
            written.append({'Path': str(dst), 'SHA256': sha(data), 'PreviousPresent': dst.exists()})
            atomic_write(dst, data)
        else:
            written.append({'Path': str(dst), 'SHA256': sha(data)})
    if rollback:
        atomic_write(rollback/'changes.json', (json.dumps(written, indent=2)+'\n').encode('utf8'))
    emit({'Operation': 'restore', 'Applied': args.apply, 'Status': 'Partial' if gaps or not outputs else 'Verified',
          'ChangedFiles': written, 'Adaptations': changes, 'Gaps': gaps, 'RollbackRoot': str(rollback) if rollback else None,
          'Authentication': 'Current identity preserved; login stores excluded', 'Functional': 'NotChecked'}, args.report if args.apply else None)


def stdio_probe(server):
    command = server.get('command')
    if not command:
        return {'Status': 'Failed', 'Reason': 'MissingCommand'}
    env = dict(os.environ)
    env.update({str(k): str(v) for k, v in server.get('env', {}).items()})
    proc = subprocess.Popen([command, *server.get('args', [])], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, text=True, encoding='utf8', env=env,
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    q = queue.Queue()
    def reader():
        for line in proc.stdout:
            try:
                q.put(json.loads(line))
            except ValueError:
                pass
    reader_thread = threading.Thread(target=reader, daemon=True)
    reader_thread.start()
    def send(value):
        proc.stdin.write(json.dumps(value)+'\n')
        proc.stdin.flush()
    def response(identifier):
        end = time.monotonic()+25
        while time.monotonic() < end:
            try:
                item = q.get(timeout=min(1, end-time.monotonic()))
            except queue.Empty:
                if proc.poll() is not None:
                    raise RuntimeError('MCP process exited')
                continue
            if item.get('id') == identifier:
                return item
        raise TimeoutError()
    try:
        send({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': initialization()})
        first = response(1)
        if 'result' not in first:
            return {'Status': 'Failed', 'Reason': 'InitializeRejected'}
        send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        send({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list', 'params': {}})
        result = response(2)
        return {'Status': 'Verified' if 'result' in result else 'Failed', 'ToolCount': len(result.get('result', {}).get('tools', []))}
    finally:
        proc.stdin.close()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=3)
        reader_thread.join(timeout=3)
        proc.stdout.close()


def initialization():
    return {'protocolVersion': '2025-03-26', 'capabilities': {}, 'clientInfo': {'name': 'preformat-verify', 'version': '2'}}


def http_probe(server):
    headers = dict(server.get('headers', server.get('http_headers', {})))
    env_token = server.get('bearer_token_env_var')
    if env_token:
        if not os.environ.get(env_token):
            return {'Status': 'NeedsAuthentication', 'Reason': 'RequiredCredentialEnvironmentMissing'}
        headers['Authorization'] = 'Bearer '+os.environ[env_token]
    headers.update({'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'})
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *unused):
            return None
    opener = urllib.request.build_opener(NoRedirect())
    def request(payload):
        return urllib.request.Request(server['url'], data=json.dumps(payload).encode(), headers=headers)
    def message(response):
        if 'text/event-stream' not in response.headers.get('Content-Type', ''):
            return json.loads(response.read(1024*1024).decode('utf8'))
        size = 0
        while size < 1024*1024:
            line = response.readline(65536).decode('utf8')
            size += len(line)
            if not line:
                break
            if line.startswith('data:'):
                value = json.loads(line[5:].strip())
                if value.get('id') is not None:
                    return value
        raise ValueError('No bounded MCP response')
    def rejected(obj, status):
        text = str(obj.get('msg', obj.get('error', {}).get('message', ''))).lower()
        auth = any(s in text for s in ['auth', 'token', 'credential', 'api key', 'unauthorized'])
        return {'Status': 'NeedsAuthentication' if auth else 'Failed', 'HttpStatus': status,
                'Reason': 'ProviderAuthenticationRejected' if auth else 'InitializeOrToolListRejected'}
    try:
        with opener.open(request({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': initialization()}), timeout=25) as response:
            obj = message(response)
            if not isinstance(obj.get('result'), dict) or not obj['result'].get('protocolVersion'):
                return rejected(obj, response.status)
            headers['MCP-Protocol-Version'] = obj['result']['protocolVersion']
            session = response.headers.get('Mcp-Session-Id')
            if session:
                headers['Mcp-Session-Id'] = session
        with opener.open(request({'jsonrpc': '2.0', 'method': 'notifications/initialized'}), timeout=25):
            pass
        with opener.open(request({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list', 'params': {}}), timeout=25) as response:
            obj = message(response)
            if not isinstance(obj.get('result'), dict) or not isinstance(obj['result'].get('tools'), list):
                return rejected(obj, response.status)
            return {'Status': 'Verified', 'HttpStatus': response.status, 'Initialized': True, 'ToolCount': len(obj['result']['tools'])}
    except urllib.error.HTTPError as e:
        status = e.code
        e.close()
        return {'Status': 'NeedsAuthentication' if status in [401, 403] else 'Failed', 'HttpStatus': status}


def verify(args):
    home = Path(args.home).absolute()
    codex = Path(args.codex_home).absolute() if args.codex_home else home/'.codex'
    files, gaps = discover(home, codex)
    servers = {}
    for name, path, key in [('Codex', codex/'config.toml', 'mcp_servers'), ('Claude', home/'.claude.json', 'mcpServers')]:
        if path.is_file():
            try:
                for server_name, server in structured(path, path.read_bytes()).get(key, {}).items():
                    if server.get('enabled', True):
                        servers[name+':'+server_name] = server
            except (ValueError, TypeError, UnicodeError):
                pass  # discover already records parse failure
    checks = {}
    for name, server in servers.items():
        try:
            if not args.probe_mcp:
                cmd = server.get('command')
                missing = bool(cmd and not (Path(cmd).is_file() or shutil.which(cmd)))
                checks[name] = {'Status': 'Partial' if missing else 'NotChecked', 'Reason': 'CommandMissing' if missing else 'NoProbeRequested'}
            elif server.get('url'):
                checks[name] = http_probe(server)
            else:
                checks[name] = stdio_probe(server)
        except Exception as e:
            checks[name] = {'Status': 'Failed', 'ErrorType': type(e).__name__}
    agent_states = {'Codex': 'Verified' if (codex/'config.toml').is_file() else 'MissingBackup',
                    'Claude': 'Verified' if (home/'.claude/settings.json').is_file() else 'MissingBackup'}
    emit({'Operation': 'verify', 'CheckedAt': timestamp(), 'Settings': 'Partial' if gaps or 'MissingBackup' in agent_states.values() else 'Verified',
          'AgentSettings': agent_states,
          'Files': [f['Source'] for f in files], 'Gaps': gaps, 'Mcp': checks, 'RuntimeConfigReader': 'NotChecked'}, args.report)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='operation', required=True)
    for name in ['collect', 'restore', 'verify']:
        p = commands.add_parser(name)
        p.add_argument('--home', required=True)
        p.add_argument('--platform', required=True, choices=['windows', 'wsl'])
        p.add_argument('--codex-home')
        p.add_argument('--report')
        if name != 'verify':
            p.add_argument('--apply', action='store_true')
        if name == 'collect':
            p.add_argument('--private-output', required=True)
            p.add_argument('--allow-source-root', action='append', default=[])
            p.add_argument('--additional-config', action='append', default=[])
        elif name == 'restore':
            p.add_argument('--source', required=True)
            p.add_argument('--path-map', action='append', default=[])
            p.add_argument('--dependency-directory')
            p.add_argument('--precedence', choices=['preserve-current', 'backup'], default='preserve-current')
        else:
            p.add_argument('--probe-mcp', action='store_true')
    args = parser.parse_args(argv)
    try:
        if args.report:
            no_links(args.report)
            if Path(args.report).exists() or Path(args.report).name.casefold() in AUTH_NAMES:
                raise ValueError('Use a new nonsecret report output')
        globals()[args.operation](args)
    except Exception as e:
        # Error text can include private configuration. Expose only a typed failure.
        emit({'Operation': args.operation, 'Status': 'Failed', 'ErrorType': type(e).__name__})
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
