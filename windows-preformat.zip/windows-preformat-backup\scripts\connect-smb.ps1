# Portable desktop-user reconnect. No clear password parameter or credential logging.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][ValidatePattern('^[D-Zd-z]:$')][string]$Drive,
 [Parameter(Mandatory=$true)][ValidatePattern('^\\\\[^\\]+\\[^\\]+')][string]$Target,
 [Parameter(Mandatory=$true)][string]$UserName,[switch]$Apply,[switch]$SaveCredentials)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
$Drive=$Drive.ToUpperInvariant()
$mapping=Get-SmbMapping -LocalPath $Drive -ErrorAction SilentlyContinue
$saved=Get-ItemProperty -LiteralPath ('HKCU:\Network\'+$Drive[0]) -ErrorAction SilentlyContinue
$local=Get-PSDrive -Name $Drive[0] -ErrorAction SilentlyContinue
if(($mapping -and $mapping.RemotePath -ne $Target) -or ($saved -and $saved.RemotePath -ne $Target)){throw 'Different existing drive mapping preserved'}
if($local -and -not $mapping -and $local.DisplayRoot -ne $Target){throw 'Existing physical/provider drive preserved'}
if(-not $Apply){[pscustomobject]@{Status='Preview';Drive=$Drive;Target=$Target;UserName=$UserName;SaveCredentials=[bool]$SaveCredentials};return}
if(Test-Path -LiteralPath ($Drive+'\')){
 $null=Get-ChildItem -LiteralPath ($Drive+'\') -ErrorAction Stop|Select-Object -First 1
 [pscustomobject]@{Status='Verified';Drive=$Drive;Target=$Target;AlreadyAccessible=$true;Context=[Security.Principal.WindowsIdentity]::GetCurrent().Name;CheckedAt=(Get-Date).ToUniversalTime().ToString('o')};return
}
Add-Type -Path (Join-Path $PSScriptRoot 'smb-native.cs')
# Null credentials use Windows' existing credential/session, not an empty supplied password.
$code=[PreformatSMB]::Connect($Drive,$Target,$null,$null)
$form=$null;$password=$null
try{
 if($code -ne 0){
  if($code -notin @(5,86,1326,2202,1312)){throw [ComponentModel.Win32Exception]::new($code)}
  Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing
  $form=[Windows.Forms.Form]::new();$form.Text='SMB '+$Drive;$form.Size=[Drawing.Size]::new(460,235);$form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false
  $label=[Windows.Forms.Label]::new();$label.Text=$Target+"`n"+$UserName;$label.Location=[Drawing.Point]::new(15,15);$label.Size=[Drawing.Size]::new(420,45);$form.Controls.Add($label)
  $password=[Windows.Forms.TextBox]::new();$password.UseSystemPasswordChar=$true;$password.Location=[Drawing.Point]::new(15,80);$password.Width=410;$form.Controls.Add($password)
  $ok=[Windows.Forms.Button]::new();$ok.Text='Connect';$ok.DialogResult='OK';$ok.Location=[Drawing.Point]::new(245,140);$form.Controls.Add($ok)
  $cancel=[Windows.Forms.Button]::new();$cancel.Text='Cancel';$cancel.DialogResult='Cancel';$cancel.Location=[Drawing.Point]::new(345,140);$form.Controls.Add($cancel);$form.AcceptButton=$ok;$form.CancelButton=$cancel
  if($form.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){[pscustomobject]@{Status='NeedsAuthentication';Drive=$Drive;Target=$Target};return}
  $code=[PreformatSMB]::Connect($Drive,$Target,$UserName,$password.Text)
  if($code -ne 0){throw [ComponentModel.Win32Exception]::new($code)}
  if($SaveCredentials){$server=($Target -split '\\')[2];$code=[PreformatSMB]::Save($server,$UserName,$password.Text);if($code -ne 0){throw [ComponentModel.Win32Exception]::new($code)}}
 }
 $null=Get-ChildItem -LiteralPath ($Drive+'\') -ErrorAction Stop|Select-Object -First 1
 [pscustomobject]@{Status='Verified';Drive=$Drive;Target=$Target;Context=[Security.Principal.WindowsIdentity]::GetCurrent().Name;CheckedAt=(Get-Date).ToUniversalTime().ToString('o')}
}finally{if($password){$password.Clear()};if($form){$form.Dispose()}}
