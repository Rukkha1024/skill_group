using System;
using System.Runtime.InteropServices;
using System.Text;
public static class PreformatSMB {
 [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
 private struct Resource { public uint Scope, Type, DisplayType, Usage; public string Local, Remote, Comment, Provider; }
 [DllImport("mpr.dll", CharSet=CharSet.Unicode)]
 private static extern int WNetAddConnection2W(ref Resource resource, string password, string username, uint flags);
 public static int Connect(string local, string remote, string username, string password) {
  var resource = new Resource { Type=1, Local=local, Remote=remote };
  return WNetAddConnection2W(ref resource, password, username, 1);
 }
 [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
 private struct Credential { public uint Flags, Type; public string TargetName, Comment; public ulong LastWritten;
  public uint BlobSize; public IntPtr Blob; public uint Persist, AttributeCount; public IntPtr Attributes; public string TargetAlias, UserName; }
 [DllImport("advapi32.dll", EntryPoint="CredWriteW", CharSet=CharSet.Unicode, SetLastError=true)]
 private static extern bool CredWrite(ref Credential credential, uint flags);
 public static int Save(string server, string username, string password) {
  byte[] bytes=Encoding.Unicode.GetBytes(password); IntPtr ptr=Marshal.AllocHGlobal(bytes.Length);
  try { Marshal.Copy(bytes,0,ptr,bytes.Length);
   var credential=new Credential { Type=2,TargetName=server,BlobSize=(uint)bytes.Length,Blob=ptr,Persist=2,UserName=username };
   return CredWrite(ref credential,0) ? 0 : Marshal.GetLastWin32Error();
  } finally { Array.Clear(bytes,0,bytes.Length);Marshal.Copy(bytes,0,ptr,bytes.Length);Marshal.FreeHGlobal(ptr); }
 }
}
