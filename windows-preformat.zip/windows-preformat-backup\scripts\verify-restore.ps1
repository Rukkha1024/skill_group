# Current observations only. No packages, credentials, services or mappings are changed.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Target,[string]$ResultPath,[switch]$CheckSsh)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
$targetData=Get-Content -LiteralPath $Target -Raw -Encoding UTF8|ConvertFrom-Json
if($targetData.SchemaVersion -ne 2 -or -not $targetData.Items){throw 'Nonempty normalized v2 target required'}
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();$principal=[Security.Principal.WindowsPrincipal]::new($identity)
$context=[ordered]@{Identity=$identity.Name;SID=$identity.User.Value;SessionId=[Diagnostics.Process]::GetCurrentProcess().SessionId;Elevated=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator);Platform='Windows'}
$now=(Get-Date).ToUniversalTime().ToString('o')
function Observation([string]$Status,[string]$Evidence){[ordered]@{Status=$Status;Evidence=$Evidence;CheckedAt=$now;Context=$context}}
$rows=[Collections.Generic.List[object]]::new()
$pythonPaths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($key in @('HKCU:\Software\Python\PythonCore\*\InstallPath','HKLM:\Software\Python\PythonCore\*\InstallPath','HKLM:\Software\WOW6432Node\Python\PythonCore\*\InstallPath')){
 foreach($entry in @(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue)){
  $exe=$entry.ExecutablePath;if(-not $exe -and $entry.'(default)'){$exe=Join-Path $entry.'(default)' 'python.exe'}
  if($exe -and (Test-Path -LiteralPath $exe -PathType Leaf)){$null=$pythonPaths.Add([IO.Path]::GetFullPath($exe))}
 }
}
foreach($base in @((Join-Path $env:LOCALAPPDATA 'Programs\Python'),$env:ProgramFiles)){
 if(Test-Path -LiteralPath $base){foreach($dir in @(Get-ChildItem -LiteralPath $base -Directory -Filter 'Python*')){$exe=Join-Path $dir.FullName 'python.exe';if(Test-Path -LiteralPath $exe -PathType Leaf){$null=$pythonPaths.Add([IO.Path]::GetFullPath($exe))}}}
}
$extensionFiles=@((Join-Path $env:USERPROFILE '.vscode\extensions\extensions.json'))
$profiles=Join-Path $env:APPDATA 'Code\User\profiles'
if(Test-Path -LiteralPath $profiles){$extensionFiles+=@(Get-ChildItem -LiteralPath $profiles -Filter 'extensions.json' -Recurse -File|Select-Object -ExpandProperty FullName)}
$jupyter=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($file in $extensionFiles){if(Test-Path -LiteralPath $file){foreach($e in @(Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json)){if($e.identifier.id -match '^ms-toolsai\.(jupyter|vscode-jupyter-)'){$null=$jupyter.Add($e.identifier.id)}}}}
$anacondaPaths=@((Join-Path $env:USERPROFILE 'anaconda3'),(Join-Path $env:USERPROFILE 'miniconda3'),(Join-Path $env:LOCALAPPDATA 'anaconda3'),(Join-Path $env:ProgramData 'anaconda3'))
$condaPresent=@($anacondaPaths|Where-Object {Test-Path -LiteralPath $_}).Count -gt 0
foreach($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')){
 if(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue|Where-Object {$_.DisplayName -match 'Anaconda|Miniconda'}){$condaPresent=$true}
}
foreach($item in $targetData.Items){
 $row=[ordered]@{Id=$item.Id}
 foreach($d in @('Installation','Settings','Authentication','Functional')){$row[$d]=Observation 'NotChecked' 'No current probe for this dimension'}
 switch($item.Kind){
  'SmbMapping'{
   $wanted=$item.Desired;$drive=$wanted.Drive;if(-not $drive){$drive=$wanted.LocalPath};if($drive -and $drive -notmatch ':$'){$drive+=':'}
   $unc=$wanted.Target;if(-not $unc){$unc=$wanted.Path};if(-not $unc){$unc=$wanted.RemotePath}
   if($drive -notmatch '^[A-Za-z]:$' -or $unc -notmatch '^\\\\[^\\]+\\[^\\]+'){throw 'Invalid target drive/share'}
   $saved=Get-ItemProperty -LiteralPath ('HKCU:\Network\'+$drive[0]) -ErrorAction SilentlyContinue
   $active=Get-SmbMapping -LocalPath $drive -ErrorAction SilentlyContinue
   $pathVerified=$false;$driveVerified=$false
   try{$null=Get-ChildItem -LiteralPath $unc -ErrorAction Stop|Select-Object -First 1;$pathVerified=$true}catch{}
   try{$null=Get-ChildItem -LiteralPath ($drive+'\') -ErrorAction Stop|Select-Object -First 1;$driveVerified=$true}catch{}
   $consistent=($saved -and $saved.RemotePath -eq $unc) -and (-not $active -or $active.RemotePath -eq $unc)
   $row.Settings=Observation $(if($consistent){'Verified'}else{'Partial'}) 'Persistent registry mapping compared with explicit target'
   $row.Authentication=Observation $(if($pathVerified){'Verified'}else{'NeedsAuthentication'}) 'Actual UNC directory enumeration; reachability alone is insufficient'
   $row.Functional=Observation $(if($driveVerified -and $consistent -and -not $context.Elevated){'Verified'}else{'Partial'}) 'Drive-letter access and target checked; non-elevated desktop context required'
  }
  'SshHost'{
   if($CheckSsh){
    $alias=$item.Desired.Alias;if($alias -notmatch '^[A-Za-z0-9][A-Za-z0-9_.-]*$'){throw 'Reviewed explicit SSH alias required'}
    $expected=$item.Desired.ExpectedPlatform
    if($expected -notin @('Windows','WSL')){throw 'Explicit SSH platform required'}
    $remote=if($expected -eq 'Windows'){'cmd.exe /d /c ver'}else{'uname -s'}
    $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=(Get-Command ssh.exe -ErrorAction Stop).Source
    $psi.Arguments='-o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10 '+$alias+' '+$remote
    $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
    $p=[Diagnostics.Process]::Start($psi)
    try{
     $outTask=$p.StandardOutput.ReadToEndAsync();$errTask=$p.StandardError.ReadToEndAsync()
     if(-not $p.WaitForExit(20000)){$p.Kill();$row.Authentication=Observation 'Failed' 'SSH probe timed out'}else{
      $out=$outTask.GetAwaiter().GetResult();$null=$errTask.GetAwaiter().GetResult()
      $row.Authentication=Observation $(if($p.ExitCode -eq 0){'Verified'}else{'Failed'}) 'Known-key batch SSH authentication result; stderr not exposed'
      $platformOK=($expected -eq 'Windows' -and $out -match 'Windows') -or ($expected -eq 'WSL' -and $out.Trim() -eq 'Linux')
      $row.Functional=Observation $(if($p.ExitCode -eq 0 -and $platformOK){'Partial'}else{'Failed'}) $(if($platformOK){'Remote OS matches; actual VS Code connection still needs separate evidence'}else{'Remote OS probe did not match target'})
     }
    }finally{$p.Dispose()}
   }
  }
  'Exclusion'{
   $name=$item.Desired.Name;$absent=$null
   if($name -match 'Jupyter'){$absent=$jupyter.Count -eq 0;$proof='Current local VS Code registrations checked; selected Python package check still required'}
   elseif($name -match 'Anaconda|Conda'){$absent=-not $condaPresent;$proof='Current known paths/uninstall metadata checked'}
   if($null -ne $absent){$row.Functional=Observation $(if($absent){'Partial'}else{'Failed'}) $proof}
  }
 }
 $rows.Add([pscustomobject]$row)
}
$result=[ordered]@{SchemaVersion=2;VerifiedAt=$now;Context=$context;Items=$rows.ToArray();Constraints=[ordered]@{StandalonePythonCount=$pythonPaths.Count;StandalonePythonPaths=@($pythonPaths);ExpectedPythonCount=$targetData.Preferences.StandaloneWindowsPythonCount;PythonCountMatches=($pythonPaths.Count -eq $targetData.Preferences.StandaloneWindowsPythonCount);JupyterExtensionIds=@($jupyter);CondaPresent=$condaPresent};ReadOnly=$true}
if($ResultPath){if([IO.Path]::GetFullPath($ResultPath) -eq [IO.Path]::GetFullPath($Target)){throw 'Do not overwrite target'};if(Test-Path -LiteralPath $ResultPath){throw 'Use a new observation output'};[IO.File]::WriteAllText([IO.Path]::GetFullPath($ResultPath),($result|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))}
$result|ConvertTo-Json -Depth 12
