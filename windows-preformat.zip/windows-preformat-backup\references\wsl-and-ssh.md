# WSL filesystem and private SSH backups

## WSL capture and export

Enumerate every registration and its default UID, storage location and WSL generation; inspect actual `/etc/os-release`, user home, systemd configuration and packages per distro. Use `scripts/collect-wsl.sh` for baseline/package metadata. Capture additional Conda/Python/Rust/other manager exports if present and in scope; the baseline helper explicitly records discovered locations and supplementation, not a complete replacement for those exports.

Do not infer what is installed from a non-login PATH alone. Conversely, do not source arbitrary user startup files just to discover paths. Inspect conventional install directories and package manifests. Avoid arbitrary agent version commands: a prior Droid version query performed a self-update. A directory or symlink needs an actual existence/resolution check; do not assert it is broken without evidence.

For an authorized filesystem backup, inspect running work and save/coordinate active editors, builds or databases before stopping that distro. An idle distro may be stopped as a normal backup step already within the user's authorized workflow; a live job needs coordination, not forced termination on assumption.

Apply confidential-storage controls to full exports, not just the separate SSH folder: homes can contain API/CLI auth, private keys and history. Check FAT32's 4,294,967,295-byte per-file limit before writing tar/ZIP/encrypted containers. A single encrypted container on FAT32 has the same size limit. If the chosen destination cannot hold/protect the export, resolve an alternate suitable destination or an explicitly selected encrypted/split workflow. Preserve unlock information through the user's chosen recovery method, not in logs. Verify final segments and a reconstruction/import before claiming a split backup usable. Do not format/convert a user's existing drive to work around this.

Export to a new partial filename with `wsl --export`, check its exit status, then rename only that exact file to the final tar after successful export. Never overwrite a previous export. Capture file size, SHA-256, archive-member evidence and status. Verify relevant homes/configs exist in the tar, including whether `.ssh` is a directory, link, or only `known_hosts`.

A proportionate import test uses a unique new name/path on a suitable disk, outside the original registration's storage. Use the exported tar, compare meaningful metadata/content and explicitly record limits (sample hashes/counts are not every-file byte comparison). Preserve the original registration/default UID. Before unregistering a test distro, resolve that exact newly created registration and canonical storage path; refuse cleanup if it is unexpected or equals a user distro. If cleanup is blocked by a tool/policy, report it and preserve the test copy; do not bypass the block.

If the desired target is fresh/minimal, keep the tar for selected recovery. Import to a distinct recovery name, do not make it the default, and copy the selected files. Do not copy old `.bashrc`, `.profile`, Conda/Rust directories or all `.local/bin` into a fresh minimal environment without checking their effects. A full import brings all extra tools back. Imported distros may default to root: set the intended existing user using supported WSL management or a merged `[user] default=...` in `/etc/wsl.conf`. New distro names and releases must come from current support, not an old Store package version.

## Windows and Linux SSH are separate

For multiple original distros, record each original name/UID/home/export, its chosen restore mode (fresh minimal, full import, recovery only, or excluded), its target registration and dependent Plan 9 mappings. Preserve all requested original exports. If a singular fresh target conflicts with multiple required mapped names, resolve that target choice while independent collection continues; never silently discard or rename a mapped registration.

Check the actual Windows profile `.ssh`, Linux user homes, root/system SSH configs, Git client config, VS Code `remote.SSH.*`, included config files, explicit `IdentityFile`/certificate/known-host/agent paths, service state, resolved SSH executable and agent availability. Do not execute `Match exec` or proxy commands merely to inspect config. A WSL tar may contain only Linux `known_hosts` while all real private keys are on Windows.

An SSH backup request normally includes the identified local configuration and key files needed for restoration, to the user's approved destination. It does not imply uploading keys, dumping unrelated credentials, exporting Windows DPAPI secrets or changing live keys. Keep passphrases out of logs/files. Hardware-backed keys and agent-only identities need their original files/device or an explicit coverage gap.

Track references as a coverage graph: canonical source file, referring config/directive/condition, resolved path, backed-up path/hash or gap. Follow recursive `Include` files/globs in their correct Windows/Linux/profile context, with a visited set to prevent cycles. Resolve home/environment/SSH tokens only where their values are known; host-dependent tokens or conditional paths can remain explicit unresolved entries. Do not execute conditions to discover paths. A symlinked `.ssh` root needs deliberate target resolution and scope verification before enumerating it; an empty no-follow listing is not proof that it has no keys. Do not copy an entire external directory just because one referenced file resides there.

## Private backup mechanics

Use a private sibling directory, not the ordinary inventory folder/ZIP. Before writing private files on NTFS, protect the destination DACL for the current authorized user, SYSTEM and Administrators. Record original SDDL/SIDs for evidence only. On filesystems/remote targets without adequate access control, resolve an appropriate private/encrypted destination before copying; do not silently leave unencrypted private keys broadly readable.

Copy source files as bytes, preserve original files, and compare source/copy SHA-256. Include config backups/public keys/known-host history when in scope. Follow external file references deliberately; inspect symlinks instead of silently following a tree outside the resolved scope. Record system configs that were absent rather than fabricating them.

Parse JSONC safely when extracting VS Code SSH preferences. Copy only `remote.SSH.*`, not the entire file's unrelated API tokens/preferences. Record client versus server/agent configuration without enabling a server or changing live services. An agent's stored identities are not necessarily portable across Windows reinstalls; do not claim they were backed up if only service metadata was captured.

Build private-payload checksums and a private ZIP beneath the already protected directory, with output outside the source subtree to avoid including itself. Verify ZIP members against payload files and verify the resulting ACLs. The ZIP is not encrypted simply because NTFS access is restricted. Keep its expected hash in inventory status so it can be verified before extraction.

## Restore SSH

Windows account SIDs can change even if the username stays the same. Use an authorized administrator if the old private backup ACL blocks access, extract into a restricted new-user directory, and set restored private-key ownership/permissions for the new account. Do not blindly replay old SDDL. Preserve existing conflicting keys/configs until resolved. Merge Git/VS Code settings, adapting executable and include paths to the actual environment.

For Linux, establish the intended owner and `.ssh` mode 700, with private keys/config mode 600 where appropriate. Referenced keys on Windows/elsewhere are not automatically in a Linux export. Validate intended host/user/key use without printing key bodies or disabling host-key verification. Actual SSH/SMB authentication may still need user interaction; report that separately from byte-level backup validity.

## Workstation Windows and WSL are separate remote targets

Do not infer the Windows SSH endpoint from a WSL host's name or an old VS Code remotePlatform entry. Resolve both devices, authenticate with existing keys and identify the actual OS/server platform. A Windows SSH server may launch a WSL terminal; its default shell alone is not platform evidence. Preserve unrelated entries, keys, host verification and remote preferences.

For this user consolidate workstation entries to `cho-workstation` (Windows) and `cho-workstation-wsl` (WSL). Treat case-only aliases as distinct input until resolved; migrate references with a case-sensitive JSON/JSONC parser. Set VS Code's actual config/client paths, consolidate remote platform entries and obsolete history, and preserve active sessions. Do not create more aliases as diagnostics. Check the host picker and actual VS Code server connection; SSH command success cannot prove an editor window connected.

Aliases, addresses and expected platforms are separate target fields. verify-restore.ps1 optionally probes reviewed aliases with BatchMode, StrictHostKeyChecking=yes and bounded timeouts. SSH configs can contain executable directives; do not probe unreviewed configs. Fingerprint mismatches stop that target instead of disabling verification.
