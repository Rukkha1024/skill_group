# Metadata only; does not copy private keys, install packages or alter services.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$OutputDirectory,[switch]$IncludePackageManagers)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -eq 'Desktop'){$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+$env:PSModulePath}
$root=[IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $root) { throw 'Use a new output directory; existing snapshots will not be overwritten' }
New-Item -ItemType Directory -Path $root | Out-Null
$utf8=[Text.UTF8Encoding]::new($false)
$statuses=[Collections.Generic.List[object]]::new()
function Redact([string]$Value) {
    $Value=$Value -replace '(https?://)[^/@\x22\x5c\s]+:[^/@\x22\x5c\s]+@','$1[REDACTED]@'
    $Value=$Value -replace '(/t/)[^/\x22\x5c\s]+','$1[REDACTED]'
    return ($Value -replace '(?i)([?&](?:token|key|password|secret|auth)=)[^&\x22\x5c\s]+','$1[REDACTED]')
}
function Protect-Value($Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [string]) { return (Redact $Value) }
    if ($Value -is [Collections.IDictionary]) {
        $result=[ordered]@{}
        foreach ($key in $Value.Keys) { $result[[string]$key]=Protect-Value $Value[$key] }
        return $result
    }
    if ($Value -is [Collections.IEnumerable]) {
        $items=[Collections.Generic.List[object]]::new()
        foreach ($item in $Value) { $items.Add((Protect-Value $item)) }
        return ,($items.ToArray())
    }
    $type=$Value.GetType()
    if ($type.IsPrimitive -or $type.IsEnum -or $Value -is [decimal] -or $Value -is [datetime] -or $Value -is [datetimeoffset] -or $Value -is [guid] -or $Value -is [version]) { return $Value }
    $result=[ordered]@{}
    foreach ($property in $Value.PSObject.Properties) { if ($property.IsGettable) { $result[$property.Name]=Protect-Value $property.Value } }
    return $result
}
function Save-Data([string]$Name,$Value) { [IO.File]::WriteAllText((Join-Path $root $Name),(ConvertTo-Json -InputObject (Protect-Value $Value) -Depth 14),$utf8) }
function Capture([string]$Name,[scriptblock]$Action) {
    try { $value=@(& $Action); Save-Data $Name $value; $statuses.Add([pscustomobject]@{File=$Name;Success=$true}) }
    catch { $statuses.Add([pscustomobject]@{File=$Name;Success=$false;Error=(Redact $_.Exception.Message)}) }
}
function Native([string]$Name,[string]$Executable,[string[]]$Arguments) {
    $savedPreference=$ErrorActionPreference
    $ErrorActionPreference='Continue'
    try {
        if (-not (Get-Command $Executable -ErrorAction SilentlyContinue)) { throw 'Executable not found' }
        $lines=@(& $Executable @Arguments 2>&1); $code=$LASTEXITCODE
        [IO.File]::WriteAllText((Join-Path $root $Name),(Redact (($lines | ForEach-Object { $_.ToString() }) -join "`n")),$utf8)
        $statuses.Add([pscustomobject]@{File=$Name;Success=($code -eq 0);ExitCode=$code})
    } catch { $statuses.Add([pscustomobject]@{File=$Name;Success=$false;Error=(Redact $_.Exception.Message)}) }
    finally { $ErrorActionPreference=$savedPreference }
}
Save-Data 'snapshot.json' ([ordered]@{CapturedAt=(Get-Date).ToString('o');Computer=$env:COMPUTERNAME;User=$env:USERNAME;Profile=$env:USERPROFILE;Root=$root;Purpose='Metadata only; filesystem/private-key backups are separate';PackageManagerQueriesRequested=[bool]$IncludePackageManagers})
Capture 'windows-system.json' { Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture }
Capture 'computer.json' { Get-CimInstance Win32_ComputerSystem | Select-Object Name,Domain,Workgroup,Manufacturer,Model }
Capture 'disks.json' { Get-Disk | Select-Object Number,FriendlyName,BusType,Size,IsBoot,IsSystem }
Capture 'volumes.json' { Get-Volume | Select-Object DriveLetter,FileSystemLabel,FileSystem,Size,SizeRemaining }
Capture 'partitions.json' { Get-Partition | Select-Object DiskNumber,PartitionNumber,DriveLetter,Size,Type }
$registries=@(@{Scope='Machine64';Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'},@{Scope='Machine32';Path='HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'},@{Scope='CurrentUser';Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'})
$apps=@(foreach ($registry in $registries) {
    Get-ItemProperty -Path $registry.Path -ErrorAction SilentlyContinue | Where-Object DisplayName | ForEach-Object {
        [pscustomobject]@{Name=$_.DisplayName;Version=$_.DisplayVersion;Publisher=$_.Publisher;InstallLocation=$_.InstallLocation;Scope=$registry.Scope;RegistryKey=$_.PSChildName;SystemComponent=$_.SystemComponent;ParentKeyName=$_.ParentKeyName}
    }
}) | Sort-Object Name,Version,Scope
Save-Data 'windows-programs.json' @($apps)
# Use BOM for human CSV interoperability, including Korean names in Excel.
$csv=((Protect-Value $apps) | ForEach-Object { [pscustomobject]$_ } | ConvertTo-Csv -NoTypeInformation) -join "`r`n"
[IO.File]::WriteAllText((Join-Path $root 'windows-programs.csv'),$csv,[Text.UTF8Encoding]::new($true))
Capture 'windows-store-apps.json' { Get-AppxPackage | Select-Object Name,Version,PackageFamilyName,Architecture,IsFramework,NonRemovable,InstallLocation | Sort-Object Name }
Capture 'start-menu-apps.json' { Get-StartApps | Sort-Object Name }
Capture 'tool-locations.json' { Get-Command winget,wsl,choco,scoop,node,npm,python,conda,code,git,codex,claude,ssh,tailscale -All -ErrorAction SilentlyContinue | Select-Object Name,Source }
Capture 'agent-settings-discovery.json' {
    $codexHome=if($env:CODEX_HOME){$env:CODEX_HOME}else{Join-Path $env:USERPROFILE '.codex'}
    foreach($entry in @(@{Agent='Codex';Path=(Join-Path $codexHome 'config.toml')},@{Agent='Codex';Path=(Join-Path $codexHome 'hooks.json')},@{Agent='Codex';Path=(Join-Path $codexHome 'AGENTS.md')},@{Agent='Claude';Path=(Join-Path $env:USERPROFILE '.claude\settings.json')},@{Agent='Claude';Path=(Join-Path $env:USERPROFILE '.claude\settings.local.json')},@{Agent='Claude';Path=(Join-Path $env:USERPROFILE '.claude\CLAUDE.md')},@{Agent='Claude';Path=(Join-Path $env:USERPROFILE '.claude.json')})) {
        $file=Get-Item -LiteralPath $entry.Path -ErrorAction SilentlyContinue
        [pscustomobject]@{Agent=$entry.Agent;Path=$entry.Path;Exists=[bool]$file;Bytes=if($file){$file.Length}else{$null};Coverage='MetadataOnly';PrivatePayloadRequired=$true}
    }
}
Capture 'program-directories.json' { foreach ($directory in @($env:ProgramFiles,${env:ProgramFiles(x86)},(Join-Path $env:LOCALAPPDATA 'Programs'),(Join-Path $env:USERPROFILE '.local\bin'))) { if ($directory -and (Test-Path -LiteralPath $directory)) { Get-ChildItem -LiteralPath $directory | Select-Object @{N='Parent';E={$directory}},Name,Mode,LinkType,Target } } }
Capture 'path.json' { [pscustomobject]@{User=[Environment]::GetEnvironmentVariable('Path','User');Machine=[Environment]::GetEnvironmentVariable('Path','Machine')} }
Capture 'smb-client.json' { Get-SmbClientConfiguration | Select-Object * -ExcludeProperty Cim*,PS* }
Capture 'smb-server.json' { Get-SmbServerConfiguration | Select-Object * -ExcludeProperty Cim*,PS* }
Capture 'smb-shares.json' { Get-SmbShare | Select-Object Name,Path,Description,Special,EncryptData,FolderEnumerationMode,CachingMode }
Capture 'smb-share-permissions.json' { Get-SmbShare | ForEach-Object { Get-SmbShareAccess -Name $_.Name | Select-Object Name,AccountName,AccessControlType,AccessRight } }
Capture 'smb-mappings-active.json' { Get-SmbMapping | Select-Object LocalPath,RemotePath,Status }
Capture 'smb-connections.json' { Get-SmbConnection | Select-Object ServerName,ShareName,UserName,Dialect,Encrypted }
Capture 'network-drives-saved.json' { Get-ItemProperty -Path 'HKCU:\Network\*' -ErrorAction SilentlyContinue | Select-Object @{N='DriveLetter';E={$_.PSChildName}},RemotePath,UserName,ProviderName,ConnectionType }
Capture 'network-profiles.json' { Get-NetConnectionProfile | Select-Object Name,InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity }
Capture 'network-addresses.json' { Get-NetIPAddress | Select-Object InterfaceAlias,IPAddress,AddressFamily,PrefixLength }
Capture 'network-services.json' { Get-Service LanmanServer,LanmanWorkstation,FDResPub,fdPHost,'ssh-agent',sshd -ErrorAction SilentlyContinue | Select-Object Name,@{N='Status';E={$_.Status.ToString()}},@{N='StartType';E={$_.StartType.ToString()}} }
Capture 'smb-firewall.json' { Get-NetFirewallRule | Where-Object { $_.Name -match 'SMB|FPS|NETDIS|WSL|Samba' -or $_.DisplayName -match 'SMB|WSL|Samba' } | ForEach-Object { $rule=$_; $port=$rule | Get-NetFirewallPortFilter; $address=$rule | Get-NetFirewallAddressFilter; [pscustomobject]@{Name=$rule.Name;DisplayName=$rule.DisplayName;Enabled=$rule.Enabled.ToString();Direction=$rule.Direction.ToString();Action=$rule.Action.ToString();Profile=$rule.Profile.ToString();Protocol=$port.Protocol;LocalPort=$port.LocalPort;RemotePort=$port.RemotePort;LocalAddress=$address.LocalAddress;RemoteAddress=$address.RemoteAddress} } }
Capture 'wsl-distributions.json' { Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss\*' -ErrorAction SilentlyContinue | Select-Object DistributionName,Version,DefaultUid,BasePath,PackageFamilyName,Flags }
Capture 'ssh-user-file-metadata.json' { $ssh=Join-Path $env:USERPROFILE '.ssh'; if (Test-Path -LiteralPath $ssh) { Get-ChildItem -LiteralPath $ssh -Force | Select-Object Name,Length,Mode,LinkType,Target } }
$registeredWsl=@(Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss\*' -ErrorAction SilentlyContinue)
$wslPresent=($registeredWsl.Count -gt 0 -or $apps.Name -contains 'Windows Subsystem for Linux')
$wslQueries=@()
if ($wslPresent) { $wslQueries=@(@{File='wsl-version.txt';Arguments='--version'},@{File='wsl-list.txt';Arguments='--list --verbose'}) }
else { $statuses.Add([pscustomobject]@{File='wsl-information';Success=$true;Skipped=$true;Reason='No registered distro/WSL installation detected; avoid installer bootstrap prompts'}) }
foreach ($query in $wslQueries) {
    try {
        $info=[Diagnostics.ProcessStartInfo]::new(); $info.FileName=(Get-Command wsl.exe -ErrorAction Stop).Source; $info.Arguments=$query.Arguments
        $info.UseShellExecute=$false; $info.RedirectStandardOutput=$true; $info.RedirectStandardError=$true; $info.StandardOutputEncoding=[Text.Encoding]::Unicode; $info.StandardErrorEncoding=[Text.Encoding]::Unicode
        $process=[Diagnostics.Process]::Start($info)
        try { $outTask=$process.StandardOutput.ReadToEndAsync(); $errTask=$process.StandardError.ReadToEndAsync(); $process.WaitForExit(); $output=$outTask.GetAwaiter().GetResult()+$errTask.GetAwaiter().GetResult(); [IO.File]::WriteAllText((Join-Path $root $query.File),$output,$utf8); $statuses.Add([pscustomobject]@{File=$query.File;Success=($process.ExitCode -eq 0);ExitCode=$process.ExitCode}) }
        finally { $process.Dispose() }
    } catch { $statuses.Add([pscustomobject]@{File=$query.File;Success=$false;Error=$_.Exception.Message}) }
}
$wslConfig=Join-Path $env:USERPROFILE '.wslconfig'
if (Test-Path -LiteralPath $wslConfig) { [IO.File]::WriteAllText((Join-Path $root 'wslconfig.txt'),(Redact (Get-Content -LiteralPath $wslConfig -Raw -Encoding UTF8)),$utf8) }
Native 'net-use.txt' 'net.exe' @('use')
Native 'portproxy.txt' 'netsh.exe' @('interface','portproxy','show','all')
if ($IncludePackageManagers) {
    if (Get-Command winget.exe -ErrorAction SilentlyContinue) { Native 'winget-export.log.txt' 'winget.exe' @('export','--output',(Join-Path $root 'winget-export.json'),'--include-versions','--disable-interactivity'); Native 'winget-sources.ndjson' 'winget.exe' @('source','export') }
    if (Get-Command choco.exe -ErrorAction SilentlyContinue) { Native 'chocolatey-packages.txt' 'choco.exe' @('list','--limit-output') }
    if (Get-Command npm.cmd -ErrorAction SilentlyContinue) { Native 'npm-global.json' 'npm.cmd' @('list','-g','--depth=0','--json') }
    if (Get-Command code.cmd -ErrorAction SilentlyContinue) { Native 'vscode-extensions.txt' 'code.cmd' @('--list-extensions','--show-versions') }
}
Save-Data 'supplementation.json' ([ordered]@{MetadataOnly=$true;PrivateSshBackupRequiredSeparately=$true;AgentSettingsPrivatePayloadRequiredSeparately=$true;DesktopSettingsPayloadRequiredSeparately=$true;FullWslExportSeparate=$true;PythonCondaRustAndOtherPackageManagers='Inspect installations and capture corresponding exports per skill references';NativeAgentVersions='Use static/package evidence; do not invoke arbitrary agent executables';HumanKoreanListAndRestoreTarget='Generate from actual evidence and latest user scope';PasswordsOrLicenseKeysExported=$false})
Save-Data 'collection-status.json' @($statuses)
[pscustomobject]@{Output=$root;UninstallEntries=$apps.Count;Failures=@($statuses | Where-Object { -not $_.Success }).Count;MetadataOnly=$true}
